package co.edu.uniquindio.proyectofinal.controladores;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.stage.Stage;
import org.w3c.dom.Text;

import java.net.URL;
import java.util.ResourceBundle;

public class ElegirTipoProductoController {
    @FXML
    private ResourceBundle resources;

    @FXML
    private Text TextSeleccionTipo;

    @FXML
    private URL location;

    @FXML
    private ComboBox<String> OnComboBoxTipo;


    public void initialize() {
        OnComboBoxTipo.getItems().addAll("Plato", "Bebida");
    }
    @FXML
    private Button OnSeleccionarButton;

    @FXML
    public String OnSeleccionarButton() {
        Stage stage = (Stage) OnSeleccionarButton.getScene().getWindow();
        // Cierra la Stage
        stage.close();
        return OnComboBoxTipo.getValue();


    }
}
