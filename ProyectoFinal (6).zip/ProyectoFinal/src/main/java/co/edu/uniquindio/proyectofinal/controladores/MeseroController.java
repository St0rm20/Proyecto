package co.edu.uniquindio.proyectofinal.controladores;

import co.edu.uniquindio.proyectofinal.app.CafeteriaApp;
import co.edu.uniquindio.proyectofinal.modulo.facade.AlertaFacade;
import co.edu.uniquindio.proyectofinal.modulo.factory.ProductoFactory;
import co.edu.uniquindio.proyectofinal.modulo.producto.Bebida;
import co.edu.uniquindio.proyectofinal.modulo.producto.Pedido;
import co.edu.uniquindio.proyectofinal.modulo.producto.Plato;
import co.edu.uniquindio.proyectofinal.modulo.producto.Producto;
import co.edu.uniquindio.proyectofinal.modulo.builders.BuilderPlato;
import javafx.collections.FXCollections;
import javafx.collections.transformation.FilteredList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.Objects;
import java.util.ResourceBundle;

public class MeseroController {
    private Pedido pedidoActual;
    private FilteredList<Producto> filteredProductosList; // Lista filtrada de Producto
    private Producto productoSeleccionado;

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private ImageView imageLogoEmpresa;

    @FXML
    private Button onAgregarPedido;

    @FXML
    private TableView<Producto> tablaProductos;

    @FXML
    private TableColumn<Producto, Double> colCantidad;

    @FXML
    private TableColumn<Producto, String> colTipo;

    @FXML
    private TableColumn<Producto, String> colNombre;

    @FXML
    private Button onEliminarPedido;

    @FXML
    private Button onConsultar;

    @FXML
    private TextField getTextNombreProducto;

    @FXML
    private TextField getTextPrecio;

    @FXML
    private TextField getTextConsultaPorNombre;

    @FXML
    private TextArea getTextDescripcion;

    @FXML
    private void onCerrarSesion() throws IOException {
        CafeteriaApp.setRoot("/co/edu/uniquindio/proyectofinal/InicioSesion.fxml");
    }

    @FXML
    void onAgregarPedido() throws Exception {
        agregarProducto();
    }

    @FXML
    void onEliminarPedido() {
        eliminarProducto();
    }

    @FXML
    void onConsultar() {
        String nombre = getTextConsultaPorNombre.getText();
        if (!nombre.isEmpty()) {
            filteredProductosList.setPredicate(p -> p.getNombre().contains(nombre));
        } else {
            filteredProductosList.setPredicate(p -> true);
        }
    }

    @FXML
    private void initialize() {
        // Inicializar la lista filtrada con una lista vacía o una lista de productos existente
        filteredProductosList = new FilteredList<>(FXCollections.observableArrayList());

        // Configurar las columnas de la tabla
        colNombre.setCellValueFactory(new PropertyValueFactory<>("nombre"));
        colTipo.setCellValueFactory(new PropertyValueFactory<>("tipo"));
        colCantidad.setCellValueFactory(new PropertyValueFactory<>("cantidad"));

        // Vincular la tabla con la lista filtrada
        tablaProductos.setItems(filteredProductosList);
    }

    private Plato buildPlato() {
        return new BuilderPlato()
                .setNombre(getTextNombreProducto.getText())
                .setPrecio(Double.parseDouble(getTextPrecio.getText()))
                .setDescripcion(getTextDescripcion.getText())
                .build();
    }

    private Bebida buildBebida() {
        return (Bebida) ProductoFactory.crearProducto(
                getTextNombreProducto.getText(),
                Double.parseDouble(getTextPrecio.getText()),
                getTextDescripcion.getText());
    }

    private void agregarProducto() {
        try {
            if (validarFormato()) {
                String selectedValue = seleccionarTipo();
                if (selectedValue != null) {
                    Producto producto;
                    if ("Plato".equals(selectedValue)) {
                        producto = buildPlato();
                    } else if ("Bebida".equals(selectedValue)) {
                        producto = buildBebida();
                    } else {
                        throw new Exception("Tipo de producto no válido");
                    }

                    if (!productoExiste(producto)) {
                        pedidoActual.agregarProducto(producto);
                    } else {
                        AlertaFacade.mostrarError("El producto ya existe");
                    }
                }
            } else {
                AlertaFacade.mostrarError("Por favor ingrese los datos correctamente");
            }
        } catch (NumberFormatException e) {
            AlertaFacade.mostrarError("El precio debe ser un número válido");
        } catch (Exception e) {
            AlertaFacade.mostrarError("Ocurrió un error al agregar el producto: " + e.getMessage());
        }
    }

    private boolean validarFormato() {
        return !getTextNombreProducto.getText().isEmpty()
                && !getTextDescripcion.getText().isEmpty()
                && !getTextPrecio.getText().isEmpty()
                && esNumero(getTextPrecio.getText());  // Validar que sea un número
    }

    private boolean esNumero(String texto) {
        try {
            Double.parseDouble(texto);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    private String seleccionarTipo() throws Exception {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/co/edu/uniquindio/proyectofinal/ElegirTipoProducto.fxml"));
        Parent root = fxmlLoader.load();

        // Crear una nueva escena y mostrarla en una nueva ventana (Stage)
        Scene scene = new Scene(root);
        Stage stage = new Stage();
        stage.setScene(scene);
        stage.showAndWait();

        ElegirTipoProductoController elegirTipoProductoController = fxmlLoader.getController();
        return elegirTipoProductoController.OnSeleccionarButton();
    }

    private boolean productoExiste(Producto producto) {
        for (Producto a : pedidoActual.getProductos()) {
            if (Objects.equals(a.getNombre(), producto.getNombre())) {
                return true;
            }
        }
        return false;
    }

    private void eliminarProducto() {
        Producto producto = tablaProductos.getSelectionModel().getSelectedItem();
        if (producto != null) {
            pedidoActual.getProductos().remove(producto);
        }
        limpiarDatos();
    }

    private void limpiarDatos() {
        getTextNombreProducto.setText("");
        getTextPrecio.setText("");
        getTextDescripcion.setText("");
    }
}
