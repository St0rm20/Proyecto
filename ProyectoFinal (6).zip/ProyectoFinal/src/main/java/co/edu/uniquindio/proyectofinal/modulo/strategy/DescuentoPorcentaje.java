package co.edu.uniquindio.proyectofinal.modulo.strategy;

public class DescuentoPorcentaje implements  DescuentoStrategy{
    private final double porcentaje;
    private final String nombre;
    private final String tipo = "Porcentaje";
    
    //constructor
    public DescuentoPorcentaje(double porcentaje, String nombre){
        this.porcentaje = porcentaje;
        this.nombre = nombre;
    }
    /**Método que aplica un descuento al precio inicial a pagar por el plato,
     *basado en un porcentaje.
     */
    @Override
    public double aplicarDescuento(double precio){
        return precio - (precio *(porcentaje/100));
    }
    @Override
    public double getValor() {
        return porcentaje;
    }
    @Override
    public String getNombre() {
        return nombre;
    }
    @Override
    public String getTipo(){
        return tipo;
    }
}
