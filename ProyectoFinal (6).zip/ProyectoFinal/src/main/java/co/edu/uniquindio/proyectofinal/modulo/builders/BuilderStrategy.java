package co.edu.uniquindio.proyectofinal.modulo.builders;
import co.edu.uniquindio.proyectofinal.modulo.strategy.DescuentoFijo;
import co.edu.uniquindio.proyectofinal.modulo.strategy.DescuentoPorcentaje;

public class BuilderStrategy {
    private double descuento;

    public BuilderStrategy() {
    }

    /**
     * Método para establecer el descuento fijo
     *
     * @param descuento
     * @return descuento fijo
     */
    public BuilderStrategy descuentoFijo(double descuento) {
        this.descuento = descuento;
        return this;
    }

    /**
     * Método para establecer el descuento por porcentaje
     *
     * @param porcentaje
     * @return descuento porcentaje
     */
    public BuilderStrategy descuentoPorcentaje(double porcentaje) {
        this.descuento = porcentaje;
        return this;
    }

    /**
     * Método para construir una instancia de DescuentoFijo
     *
     * @return instancia de DescuentoFijo
     */
    public DescuentoFijo buildDescuentoFijo() {
        return new DescuentoFijo("Descuento Fijo",descuento);
    }

    /**
     * Método para construir una instancia de DescuentoPorcentaje
     *
     * @return instancia de DescuentoPorcentaje
     */
    public DescuentoPorcentaje buildDescuentoPorcentaje() {
        return new DescuentoPorcentaje(descuento,"DescuentoPorcentual");
    }
}

