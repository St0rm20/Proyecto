package co.edu.uniquindio.proyectofinal.modulo.producto;

public interface Producto {
    public String getDescripcion();
    public double getPrecio();
    public String getNombre();
}
