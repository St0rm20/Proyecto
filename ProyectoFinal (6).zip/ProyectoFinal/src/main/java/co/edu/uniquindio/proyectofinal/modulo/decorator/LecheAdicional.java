package co.edu.uniquindio.proyectofinal.modulo.decorator;
import co.edu.uniquindio.proyectofinal.modulo.producto.Producto;

/**
 * Clase decoradora que añade leche adicional a una bebida.
 * Extiende la clase DecoradorBebida, añadiendo una descripción adicional
 * y posiblemente otros comportamientos específicos a una bebida.
 */
public class LecheAdicional extends DecoradorBebida {

    /**
     * Constructor que inicializa el decorador con la bebida base.
     *
     * @param bebida Producto que representa la bebida a decorar.
     */
    public LecheAdicional(Producto bebida) {
        super(bebida);
    }

    /**
     * Obtiene la descripción de la bebida decorada, añadiendo "Leche".
     *
     * @return Descripción de la bebida con la adición de leche.
     */
    @Override
    public String getDescripcion() {
        return bebida.getDescripcion() + ", Leche";
    }

    /**
     * Obtiene el precio de la bebida decorada. Este método no cambia el precio
     * en esta implementación, pero podría ser sobrescrito para añadir el costo de la leche.
     *
     * @return Precio de la bebida decorada.
     */
    @Override
    public double getPrecio() {
        return bebida.getPrecio();
    }

    /**
     * Obtiene el nombre de la bebida decorada.
     *
     * @return Nombre de la bebida decorada.
     */
    @Override
    public String getNombre() {
        return bebida.getNombre();
    }
}
