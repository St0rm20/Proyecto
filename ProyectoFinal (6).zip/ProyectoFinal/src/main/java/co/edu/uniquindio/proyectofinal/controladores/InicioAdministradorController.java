package co.edu.uniquindio.proyectofinal.controladores;

import co.edu.uniquindio.proyectofinal.app.CafeteriaApp;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.image.ImageView;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class InicioAdministradorController {
    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private ImageView imageLogoEmpresa;

    @FXML
    private Button onCerrarSesion;

    @FXML
    private Button onIrInterfazAdmin;

    @FXML
    private Button onUndo;

    @FXML
    void onCerrarSesion() throws IOException {
        CafeteriaApp.setRoot("/co/edu/uniquindio/proyectofinal/Inicio.fxml");
    }

    @FXML
    void onIrInterfazAdmin() {

    }

    @FXML
    void onUndo() {

    }

    @FXML
    void initialize() {

    }
}
