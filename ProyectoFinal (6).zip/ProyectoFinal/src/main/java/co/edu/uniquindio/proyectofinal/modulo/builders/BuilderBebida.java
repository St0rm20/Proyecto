package co.edu.uniquindio.proyectofinal.modulo.builders;

import co.edu.uniquindio.proyectofinal.modulo.empleados.Cajero;
import co.edu.uniquindio.proyectofinal.modulo.producto.Bebida;

import java.time.LocalDate;

public class BuilderBebida {
    private String descripcion;
    private double precio;
    private String nombre;

    public BuilderBebida() {
    }

    /**
     * Establece la descripción de la bebida.
     *
     * @param descripcion  descripcion de la bebida.
     * @return        Instancia del BuilderBebida.
     */
    public BuilderBebida setDescripcion(String descripcion) {
        this.descripcion = descripcion;
        return this;
    }

    /**
     * Establece el precio de la bebida.
     *
     * @param precio  precio de la bebida.
     * @return        Instancia del BuilderBebida.
     */
    public BuilderBebida setPrecio(double precio) {
        this.precio = precio;
        return this;
    }

    /**
     * Establece el nombre de la bebida.
     *
     * @param nombre  descripcion de la bebida.
     * @return        Instancia del BuilderBebida.
     */
    public BuilderBebida setNombre(String nombre) {
        this.nombre = nombre;
        return this;
    }
    /**
     * Construye y retorna una instancia de Bebida.
     *
     * @return  Nueva instancia de Bebida.
     */
    public Bebida build() {
        return new Bebida(descripcion,precio,nombre);
    }
}
