package co.edu.uniquindio.proyectofinal.modulo.builders;
import co.edu.uniquindio.proyectofinal.modulo.strategy.DescuentoFijo;
public class BuilderDescuentoFijo {
    private double descuento;
    private String nombre;

    public BuilderDescuentoFijo() {
    }

    /**
     * Método para establecer el descuento fijo.
     *
     * @param descuento El descuento fijo a establecer.
     * @return El builder actual.
     */
    public BuilderDescuentoFijo setDescuentoFijo(double descuento) {
        this.descuento = descuento;
        return this;
    }

    public BuilderDescuentoFijo setNombre(String nombre) {
        this.nombre = nombre;
        return this;
    }

    /**
     * Método para construir una instancia de DescuentoFijo.
     *
     * @return Una nueva instancia de DescuentoFijo.
     */
    public DescuentoFijo build() {
        return new DescuentoFijo(nombre, descuento);
    }
}