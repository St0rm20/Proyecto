package co.edu.uniquindio.proyectofinal.controladores;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import org.w3c.dom.Text;
import javafx.stage.Stage;


import java.net.URL;
import java.util.ResourceBundle;

public class ElegirCargoEmpleadoController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private Text TextSeleccionCargo;

    @FXML
    private URL location;

    @FXML
    private ComboBox<String> OnComboBoxCargo;


    public void initialize() {
        OnComboBoxCargo.getItems().addAll("Mesero", "Cajero");
    }
    @FXML
    private Button OnSeleccionarButton;

    @FXML
    public String OnSeleccionarButton() {
        Stage stage = (Stage) OnSeleccionarButton.getScene().getWindow();
        // Cierra la Stage
        stage.close();
        return OnComboBoxCargo.getValue();


    }


}
