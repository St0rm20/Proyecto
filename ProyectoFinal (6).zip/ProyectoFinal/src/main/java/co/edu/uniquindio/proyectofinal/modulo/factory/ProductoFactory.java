package co.edu.uniquindio.proyectofinal.modulo.factory;
import co.edu.uniquindio.proyectofinal.modulo.builders.BuilderPlato;
import co.edu.uniquindio.proyectofinal.modulo.producto.Bebida;
import co.edu.uniquindio.proyectofinal.modulo.producto.Plato;
import co.edu.uniquindio.proyectofinal.modulo.producto.Producto;
import co.edu.uniquindio.proyectofinal.modulo.builders.BuilderBebida;
import co.edu.uniquindio.proyectofinal.modulo.strategy.DescuentoStrategy;

/*Patrón Factory
 *El patrón Factory en esta aplicación se utiliza para simplificar la creación de objetos complejos al encapsular
 *  la lógica de construcción dentro de métodos de fábrica estáticos. Esto permite crear productos con diferentes
 *  configuraciones de manera fácil y uniforme
 * */

public class ProductoFactory {

    /**
     * Crea una instancia de Bebida con los parámetros especificados.
     *
     * @param nombre       El nombre de la bebida.
     * @param precio       El precio de la bebida.
     * @param descripcion  La descripción de la bebida.
     * @return             Una instancia de Bebida.
     */
    public static Producto crearProducto (String nombre, double precio, String descripcion) {
            return new BuilderBebida()
                    .setNombre(nombre)
                    .setPrecio(precio)
                    .setDescripcion(descripcion)
                    .build();

      }
      /**
     * Crea una instancia de Plato con los parámetros especificados y una estrategia de descuento.
     *
     * @param nombre        El nombre del plato.
     * @param precio        El precio del plato.
     * @param descripcion   La descripción del plato.
     * @param descuento     La estrategia de descuento a aplicar en el plato.
     * @return              Una instancia de Plato.
     */
    public static Producto crearProducto(String nombre, double precio, String descripcion, DescuentoStrategy descuento) {

            return new BuilderPlato()
                    .setNombre(nombre)
                    .setPrecio(precio)
                    .setDescripcion(descripcion)
                    .setDescuentoStrategy(descuento)
                    .build();
        }


}
