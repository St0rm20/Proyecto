package co.edu.uniquindio.proyectofinal.controladores;

import co.edu.uniquindio.proyectofinal.app.CafeteriaApp;
import co.edu.uniquindio.proyectofinal.modulo.builders.BuilderCajero;
import co.edu.uniquindio.proyectofinal.modulo.builders.BuilderMesero;
import co.edu.uniquindio.proyectofinal.modulo.cafeteria.Cafeteria;
import co.edu.uniquindio.proyectofinal.modulo.empleados.Cajero;
import co.edu.uniquindio.proyectofinal.modulo.empleados.Mesero;
import co.edu.uniquindio.proyectofinal.modulo.facade.AlertaFacade;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class RegistroEmpleadoController {

    ObservableList<String> listaCargos = FXCollections.observableArrayList("Mesero", "Cajero");
    Cafeteria cafeteria = Cafeteria.getInstance();

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private AnchorPane LogoEmpresa;

    @FXML
    private DatePicker getDateFechaNacimiento;

    @FXML
    private PasswordField getPasswordContrasenia;

    @FXML
    private TextField getTextApellido;

    @FXML
    private TextField getTextCelular;

    @FXML
    private TextField getTextDireccion;

    @FXML
    private TextField getTextID;

    @FXML
    private TextField getTextNombre;

    @FXML
    private TextField getTextSueldo;

    @FXML
    private Button onRegistrar;

    @FXML
    private Button onUndo;

    @FXML
    private Label textApellido;

    @FXML
    private Label textCargo;

    @FXML
    private Label textCelular;

    @FXML
    private Label textContrasenia;

    @FXML
    private Label textDireccion;

    @FXML
    private Label textFechaNacimiento;

    @FXML
    private Label textInicioDeSesion;

    @FXML
    private Label textSueldo;

    @FXML
    private ComboBox<String> getComboBox;

    public void initialize() {
        getComboBox.getItems().addAll("Mesero", "Cajero");
    }

    @FXML
    void onRegistrar() throws Exception {
        if (validarFormato()) {
            String cargoSeleccionado = getComboBox.getValue();
            if (cargoSeleccionado != null) {
                if (cargoSeleccionado.equals("Cajero")) {
                    Cajero cajero = buildCajero();
                    cafeteria.agregarEmpleado(cajero);
                    AlertaFacade.mostrarMensajeConfirmacion("Cajero registrado con éxito");
                    CafeteriaApp.setRoot("/co/edu/uniquindio/proyectofinal/InicioCajero.fxml");
                } else if (cargoSeleccionado.equals("Mesero")) {
                    Mesero mesero = buildMesero();
                    cafeteria.agregarEmpleado(mesero);
                    AlertaFacade.mostrarMensajeConfirmacion("Mesero registrado con éxito");
                    CafeteriaApp.setRoot("/co/edu/uniquindio/proyectofinal/Mesero.fxml");
                }
            } else {
                AlertaFacade.mostrarAdvertencia("Ningún cargo seleccionado");
            }
        } else {
            AlertaFacade.mostrarAdvertencia("Formato Incorrecto");
        }
    }

    @FXML
    void onUndo() throws IOException {
        CafeteriaApp.setRoot("/co/edu/uniquindio/proyectofinal/RegistroUsuario.fxml");
    }

    private boolean validarFormato() {
        return !getTextNombre.getText().isEmpty()
                && !getTextApellido.getText().isEmpty()
                && !getTextCelular.getText().isEmpty()
                && !getTextID.getText().isEmpty()
                && !getTextSueldo.getText().isEmpty()
                && !getPasswordContrasenia.getText().isEmpty()
                && getDateFechaNacimiento.getValue() != null;
    }

    private Cajero buildCajero() {
        return new BuilderCajero(getTextID.getText(), getDateFechaNacimiento.getValue())
                .setNombre(getTextNombre.getText())
                .setApellido(getTextApellido.getText())
                .setCelular(getTextCelular.getText())
                .setDireccion(getTextDireccion.getText())
                .setSueldo(Double.parseDouble(getTextSueldo.getText()))
                .setContrasenia(getPasswordContrasenia.getText())
                .build();
    }

    private Mesero buildMesero() {
        return new BuilderMesero(getTextID.getText(), getDateFechaNacimiento.getValue())
                .setNombre(getTextNombre.getText())
                .setApellido(getTextApellido.getText())
                .setCelular(getTextCelular.getText())
                .setDireccion(getTextDireccion.getText())
                .setSueldo(Double.parseDouble(getTextSueldo.getText()))
                .setContrasenia(getPasswordContrasenia.getText())
                .build();
    }
}
