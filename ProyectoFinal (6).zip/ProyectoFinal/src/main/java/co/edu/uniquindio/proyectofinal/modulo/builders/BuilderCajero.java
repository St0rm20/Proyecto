package co.edu.uniquindio.proyectofinal.modulo.builders;

import co.edu.uniquindio.proyectofinal.modulo.cafeteria.Caja;
import co.edu.uniquindio.proyectofinal.modulo.empleados.Cajero;

import java.time.LocalDate;

/**
 * Builder para crear instancias de Cajero.
 */
public class BuilderCajero {
    private String nombre;
    private String apellido;
    private String celular;
    private String id;
    private LocalDate fechaNacimiento;
    private String direccion;
    private Double sueldo;
    private Caja caja;
    private String contrasenia;

    /**
     * Constructor para el BuilderCajero.
     *
     * @param id               ID del cajero.
     * @param fechaNacimiento  Fecha de nacimiento del cajero.
     */
    public BuilderCajero(String id, LocalDate fechaNacimiento) {
        this.id = id;
        this.fechaNacimiento = fechaNacimiento;
    }

    /**
     * Establece el nombre del cajero.
     *
     * @param nombre  Nombre del cajero.
     * @return        Instancia del BuilderCajero.
     */
    public BuilderCajero setNombre(String nombre) {
        this.nombre = nombre;
        return this;
    }

    /**
     * Establece el apellido del cajero.
     *
     * @param apellido  Apellido del cajero.
     * @return          Instancia del BuilderCajero.
     */
    public BuilderCajero setApellido(String apellido) {
        this.apellido = apellido;
        return this;
    }

    /**
     * Establece el número de celular del cajero.
     *
     * @param celular  Número de celular del cajero.
     * @return         Instancia del BuilderCajero.
     */
    public BuilderCajero setCelular(String celular) {
        this.celular = celular;
        return this;
    }

    /**
     * Establece la dirección del cajero.
     *
     * @param direccion  Dirección del cajero.
     * @return           Instancia del BuilderCajero.
     */
    public BuilderCajero setDireccion(String direccion) {
        this.direccion = direccion;
        return this;
    }

    /**
     * Establece el sueldo del cajero.
     *
     * @param sueldo  Sueldo del cajero.
     * @return        Instancia del BuilderCajero.
     */
    public BuilderCajero setSueldo(Double sueldo) {
        this.sueldo = sueldo;
        return this;
    }

    /**
     * Establece la contraseña del cajero.
     *
     * @param contrasenia  Contraseña del cajero.
     * @return             Instancia del BuilderCajero.
     */
    public BuilderCajero setContrasenia(String contrasenia) {
        this.contrasenia = contrasenia;
        return this;
    }

    /**
     * Construye y retorna una instancia de Cajero.
     *
     * @return  Nueva instancia de Cajero.
     */
    public Cajero build() {
        return new Cajero(nombre, apellido, celular, id, fechaNacimiento, direccion, sueldo, contrasenia);
    }
}
