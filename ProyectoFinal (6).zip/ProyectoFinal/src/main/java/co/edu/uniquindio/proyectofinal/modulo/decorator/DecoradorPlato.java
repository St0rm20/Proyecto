package co.edu.uniquindio.proyectofinal.modulo.decorator;

import co.edu.uniquindio.proyectofinal.modulo.producto.Producto;

/**
 * Clase decoradora para productos que son platos.
 * Implementa la interfaz Producto y actúa como un contenedor para otro Producto.
 */
public class DecoradorPlato implements Producto {
    private Producto plato;

    /**
     * Constructor para el decorador de platos.
     *
     * @param plato Producto que representa el plato a decorar.
     */
    public DecoradorPlato(Producto plato) {
        this.plato = plato;
    }

    /**
     * Obtiene la descripción del plato decorado.
     *
     * @return Descripción del plato.
     */
    @Override
    public String getDescripcion() {
        return plato.getDescripcion();
    }

    /**
     * Obtiene el precio del plato decorado.
     *
     * @return Precio del plato.
     */
    @Override
    public double getPrecio() {
        return plato.getPrecio();
    }

    /**
     * Obtiene el nombre del plato decorado.
     *
     * @return Nombre del plato.
     */
    @Override
    public String getNombre() {
        return plato.getNombre();
    }
}
