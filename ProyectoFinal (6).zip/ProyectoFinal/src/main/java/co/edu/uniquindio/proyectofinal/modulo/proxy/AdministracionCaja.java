package co.edu.uniquindio.proyectofinal.modulo.proxy;
/*Patron Proxy
 *El patrón Proxy en esta aplicación se utiliza para validar que un usuario que intenta realizar operaciones en la caja sea
 *efectivamente un cajero. Esto se hace implementando la interfaz AdministracionCaja, que define el método abrirCaja().
 * */
public interface AdministracionCaja {
    void abrirCaja();
}
