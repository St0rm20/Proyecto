package co.edu.uniquindio.proyectofinal.modulo.memento;
import java.util.Stack;
/*Patron Memento
*El patron memento permite restaurar estados previos de objetos, en este caso permite obtener estados anteriores
* de pedidos, lo cual es especialmente util para meseros quienes son los encargados de radicar los pedidos
* */
public class Caretaker {
    private Stack<PedidoMemento> historial;

    public Caretaker() {
        historial = new Stack<>();
    }

    public void agregarMemento(PedidoMemento memento) {
        historial.push(memento);
    }

    /**
     * Gestiona si debe devolver el ultimo Memento de la pila de mementos
     *
     * @return último memento o null
     */
    public PedidoMemento obtenerUltimoMemento() {
        // Primero, elimina el memento más reciente (estado actual)
        if (!historial.isEmpty()) {
            historial.pop();
        }

        // Luego, devuelve el memento que ahora está en la parte superior de la pila (estado anterior)
        if (!historial.isEmpty()) {
            return historial.peek();
        } else {
            return null;
        }
    }
}
