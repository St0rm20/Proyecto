package co.edu.uniquindio.proyectofinal.modulo.decorator;

import co.edu.uniquindio.proyectofinal.modulo.producto.Producto;
/*Aplicación del patron decorator: El patron decorator bajo el contexto de lo que pide la app
*Permite crear decoradores extras a los productos, con el objetivo de añadir toppings o adicionales,
* Ejemplo leche adicional a un cafe.
* */

public abstract class DecoradorBebida implements Producto {
    protected Producto bebida;

    /**
     * Constructor para el decorador de bebidas.
     *
     * @param bebida Producto que representa la bebida a decorar.
     */
    public DecoradorBebida(Producto bebida) {
        this.bebida = bebida;
    }

    /**
     * Obtiene la descripción de la bebida decorada.
     *
     * @return Descripción de la bebida.
     */
    @Override
    public String getDescripcion() {
        return bebida.getDescripcion();
    }

    /**
     * Obtiene el precio de la bebida decorada.
     *
     * @return Precio de la bebida.
     */
    @Override
    public double getPrecio() {
        return bebida.getPrecio();
    }
}
