package co.edu.uniquindio.proyectofinal.controladores;

import co.edu.uniquindio.proyectofinal.modulo.factory.ProductoFactory;
import co.edu.uniquindio.proyectofinal.modulo.cafeteria.Cafeteria;
import co.edu.uniquindio.proyectofinal.modulo.facade.AlertaFacade;
import co.edu.uniquindio.proyectofinal.modulo.producto.Bebida;
import co.edu.uniquindio.proyectofinal.modulo.producto.Plato;
import co.edu.uniquindio.proyectofinal.modulo.producto.Producto;
import co.edu.uniquindio.proyectofinal.modulo.strategy.DescuentoFijo;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

import java.net.URL;
import java.util.Objects;
import java.util.ResourceBundle;

public class AdministradorProductoController {
    private Cafeteria cafeteria = Cafeteria.getInstance(); // Instancia de la cafetería
    private ObservableList<Producto> listaProductos; // Lista de producto observable
    private FilteredList<Producto> filteredProductosList; // Lista filtrada de Producto
    private Producto productoSeleccionado;


    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private TableColumn<Producto, String> colNombre;

    @FXML
    private TableColumn<Producto, Double> colPrecio;

    @FXML
    private TableColumn<Producto, String> colDescripcion;

    @FXML
    private ImageView getAvatar;

    @FXML
    private TextField getTextConsultaPorNombre;

    @FXML
    private TextField getTextNombre;

    @FXML
    private TextField getTextPrecio;


    @FXML
    private TextArea getTextDescripcion;

    @FXML
    private Label nombreCajeroLabel;

    @FXML
    private Button onAgregarProducto;

    @FXML
    private Button onConsultar;

    @FXML
    private Button onActualizar;

    @FXML
    private Button onEliminarProducto;

    @FXML
    private TableView<Producto> tablaProductos;

    @FXML
    private Label textConsultaPorNombre;

    @FXML
    private Label textNombre;

    @FXML
    private Label textPrecio;

    @FXML
    void onAgregarProducto() throws Exception{
        agregarProducto();
    }

    @FXML
    void onConsultar() {
    String nombre = getTextConsultaPorNombre.getText();
        if (!nombre.isEmpty()) {
            filteredProductosList.setPredicate(p -> p.getNombre().contains(nombre));
        } else {
            filteredProductosList.setPredicate(p -> true);
        }
    }
    @FXML
    void onEliminarProducto() {
        eliminarProducto();

    }
    @FXML
    void onActualizar() {
        actualizarProducto();
    }

    @FXML
    void onLimpiar() {
        limpiarDatos();
    }

    @FXML
    void initialize() {
        listaProductos = FXCollections.observableArrayList(); // Initialize listaProductos
        inicializarValores(); // Call your initialization method
        inicializarTabla(); // Call your initialization method for the TableView
        verSeleccion();
    }


    private void inicializarValores(){
        listaProductos.addAll(cafeteria.getMenu().getListaProductos());
        filteredProductosList = new FilteredList<>(listaProductos, p -> true);
    }

    private void inicializarTabla() {
        colNombre.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getNombre()));
        colPrecio.setCellValueFactory(cellData -> new SimpleDoubleProperty(cellData.getValue().getPrecio()).asObject());
        colDescripcion.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getDescripcion()));
        tablaProductos.setItems(listaProductos);
    }

    private void agregarProducto() throws Exception {
        if (validarFormato()) {
            String selectedValue = seleccionarTipo();
            if (selectedValue != null) {
                Producto producto;
                if ("Plato".equals(selectedValue)) {
                    producto = buildPlato();
                } else if ("Bebida".equals(selectedValue)) {
                    producto = buildBebida();
                } else {
                    throw new Exception("Invalid product type");
                }

                if (!productoExiste(producto)) {
                    listaProductos.add(producto);
                    cafeteria.getMenu().getListaProductos().add(producto);
                    tablaProductos.setItems(listaProductos);
                    limpiarDatos();
                } else {
                    AlertaFacade.mostrarError("El producto ya existe");
                }
            }
        } else {
            AlertaFacade.mostrarError("Por favor ingrese los datos correctamente");
        }
    }

    private void eliminarProducto() {
        boolean confirmacion = AlertaFacade.mostrarMensajeConfirmacion("Confirmar eliminar");
        if (!confirmacion) {
            return;
        }
        Producto producto = tablaProductos.getSelectionModel().getSelectedItem();
        if (producto != null) {
            listaProductos.remove(producto); // Elimina el producto de la lista observable
            cafeteria.getMenu().eliminarProducto(producto); // Elimina el producto de la cafetería
        }
        limpiarDatos();
    }

    private boolean productoExiste(Producto producto) {
        for (Producto a : listaProductos) {
            if (Objects.equals(a.getNombre(), producto.getNombre())) {
                return true;
            }
        }
        return false;
    }

    private void actualizarProducto() {
        verSeleccion();
        if (productoSeleccionado != null) {
            if (productoSeleccionado instanceof Plato) {
                Producto productoActualizado = buildPlato();
                actualizarLista(productoSeleccionado, productoActualizado);
            } else {
                Producto productoActualizado = buildBebida();
                actualizarLista(productoSeleccionado, productoActualizado);
            }
        }
    }

    private void actualizarLista(Producto productoActual, Producto productoActualizado){
        int i = listaProductos.indexOf(productoActual);
        listaProductos.set(i, productoActualizado);
    }
    private void limpiarDatos(){
        getTextNombre.setText("");
        getTextPrecio.setText("");
        getTextDescripcion.setText("");
    }

    private void verSeleccion() {
        tablaProductos.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
            productoSeleccionado = newSelection;
            mostrarInformacionProducto(productoSeleccionado);
        });
    }

    private void mostrarInformacionProducto(Producto productoSeleccionado){
        if(productoSeleccionado!= null){
           getTextPrecio.setText(String.valueOf(productoSeleccionado.getPrecio()));
           getTextNombre.setText(productoSeleccionado.getNombre());
           getTextDescripcion.setText(productoSeleccionado.getDescripcion());
        }
    }
    private String seleccionarTipo() throws Exception{
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/co/edu/uniquindio/proyectofinal/ElegirTipoProducto.fxml"));
        Parent root = fxmlLoader.load();

        // Crear una nueva escena y mostrarla en una nueva ventana (Stage)
        Scene scene = new Scene(root);
        Stage stage = new Stage();
        stage.setScene(scene);
        stage.showAndWait();
        ElegirTipoProductoController elegirTipoProductoController = fxmlLoader.getController();
        String selectedValue = elegirTipoProductoController.OnSeleccionarButton();
        return selectedValue;
    }

    private Plato buildPlato() {

        return (Plato) ProductoFactory.crearProducto(
                getTextNombre.getText(),
                Double.parseDouble(getTextPrecio.getText()),
                getTextDescripcion.getText(),new DescuentoFijo("Descuento Fijo", 0.0));
    }



    private Bebida buildBebida() {
        return (Bebida) ProductoFactory.crearProducto(
                getTextNombre.getText(),
                Double.parseDouble(getTextPrecio.getText()),
                getTextDescripcion.getText());
    }


    private boolean esNumero(String str) {
        if (str == null) {
            return false;
        }
        try {
            Double.parseDouble(str);
        } catch (NumberFormatException e) {
            return false;
        }
        return true;
    }


    private boolean validarFormato() {
        return !getTextNombre.getText().isEmpty()
                && !getTextDescripcion.getText().isEmpty()
                && !getTextPrecio.getText().isEmpty()
                && esNumero(getTextPrecio.getText());  // Validar que sea un número
    }
}
