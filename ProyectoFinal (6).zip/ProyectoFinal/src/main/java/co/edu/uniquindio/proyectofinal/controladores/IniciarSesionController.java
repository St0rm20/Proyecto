package co.edu.uniquindio.proyectofinal.controladores;

import co.edu.uniquindio.proyectofinal.app.CafeteriaApp;
import co.edu.uniquindio.proyectofinal.modulo.cafeteria.Cafeteria;
import co.edu.uniquindio.proyectofinal.modulo.empleados.Administrador;
import co.edu.uniquindio.proyectofinal.modulo.empleados.Cajero;
import co.edu.uniquindio.proyectofinal.modulo.empleados.Empleado;
import co.edu.uniquindio.proyectofinal.modulo.empleados.Mesero;
import co.edu.uniquindio.proyectofinal.modulo.facade.AlertaFacade;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

import java.io.IOException;
import java.net.URL;
import java.util.Objects;
import java.util.ResourceBundle;

public class IniciarSesionController {
    Cafeteria cafeteria = Cafeteria.getInstance();

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private TextField claimTextContrasenia;

    @FXML
    private TextField claimTextNombre;

    @FXML
    private Button onListo;

    @FXML
    private Label textContrasenia;

    @FXML
    private Label textNombre;

    @FXML
    private Label textInicioDeSesion;

    @FXML
    void onIngresar() throws Exception {
        Empleado empleado = confirmarUsuario();
        if (empleado != null) {
            if (empleado instanceof Administrador) {
                CafeteriaApp.setRoot("/co/edu/uniquindio/proyectofinal/InicioAdministrador.fxml");
                return;
            } else if (empleado instanceof Mesero) {
                CafeteriaApp.setRoot("/co/edu/uniquindio/proyectofinal/Mesero.fxml");
                return;
            } else if (empleado instanceof Cajero) {
                cafeteria.setUsuarioActual(empleado);
                CafeteriaApp.setRoot("/co/edu/uniquindio/proyectofinal/InicioCajero.fxml", 650, 450);
                return;
            }
        }
        AlertaFacade.mostrarError("Usuario o contraseña incorrectos.");
    }

    @FXML
    private void onUndo() throws IOException {
        CafeteriaApp.setRoot("/co/edu/uniquindio/proyectofinal/Inicio.fxml");
    }

    private Empleado confirmarUsuario() {
        String nombre = claimTextNombre.getText();
        String contrasenia = claimTextContrasenia.getText();

        for (Empleado empleado : cafeteria.getListaEmpleados()) {
            if (Objects.equals(empleado.getNombre(), nombre) && Objects.equals(empleado.getContrasenia(), contrasenia)) {
                return empleado;
            }
        }

        // Ningún usuario coincide.
        AlertaFacade.mostrarError("Nombre de usuario o contraseña incorrectos.");
        return null;
    }

    private Administrador confirmarAdministrador() {
        String nombre = claimTextNombre.getText();
        String contrasenia = claimTextContrasenia.getText();

        for (Administrador administrador : cafeteria.getListaAdministradores()) {
            if (Objects.equals(administrador.getNombre(), nombre) && Objects.equals(administrador.getContrasenia(), contrasenia)) {
                return administrador;
            }
        }

        // Ningún administrador coincide.
        return null;
    }
}
