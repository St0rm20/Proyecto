package co.edu.uniquindio.proyectofinal.modulo.strategy;
/*Patrón Strategy
 *El patrón Strategy resuelve la peticion de generar varios tipos de descuentos,
 *  en esta aplicación se utiliza para darle un descuento a un cliente en algún producto de tipo plato,
 * para esto, implementa DescuentoStrategy, el cual le da a elegir entre 2 tipos de descuento.
 * */
public class DescuentoFijo implements  DescuentoStrategy {
    private final String nombre;
    private final double descuento;
    private final String tipo = "Fijo";

    //constructor
    public DescuentoFijo(String nombre, double descuento){
        this.nombre = nombre;
        this.descuento = descuento;

    }
    @Override
    public  double aplicarDescuento (double precio){
        return precio-descuento;

    }
    @Override
    public double getValor() {
        return descuento;
    }
    @Override
    public String getNombre() {
        return nombre;
    }
    @Override
    public String getTipo(){
        return tipo;
    }

}
