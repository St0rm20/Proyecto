package co.edu.uniquindio.proyectofinal.modulo.memento;
import co.edu.uniquindio.proyectofinal.modulo.producto.Pedido;
import co.edu.uniquindio.proyectofinal.modulo.producto.Producto;

import java.util.ArrayList;
import java.util.List;

public class PedidoMemento {
    private final List<Producto> listaProductos;
    private String numeroSerie;

    public PedidoMemento(List<Producto> listaProductos, String numeroSerie) {
        this.listaProductos = new ArrayList<>(listaProductos);
        this.numeroSerie = numeroSerie;
    }
    public List<Producto> getListaProductos() {
        return listaProductos;
    }
    public String getNumeroSerie() {
        return numeroSerie;
    }
}