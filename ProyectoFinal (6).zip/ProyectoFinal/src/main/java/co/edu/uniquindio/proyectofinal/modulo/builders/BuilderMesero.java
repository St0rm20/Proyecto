package co.edu.uniquindio.proyectofinal.modulo.builders;

import co.edu.uniquindio.proyectofinal.modulo.empleados.Mesero;

import java.time.LocalDate;

/**
 * Builder para crear instancias de Mesero.
 */
public class BuilderMesero {
    private String nombre;
    private String apellido;
    private String celular;
    private String id;
    private LocalDate fechaNacimiento;
    private String direccion;
    private Double sueldo;
    private String contrasenia;

    /**
     * Constructor para el BuilderMesero.
     *
     * @param id               ID del mesero.
     * @param fechaNacimiento  Fecha de nacimiento del mesero.
     */
    public BuilderMesero(String id, LocalDate fechaNacimiento) {
        this.id = id;
        this.fechaNacimiento = fechaNacimiento;
    }

    /**
     * Establece el nombre del mesero.
     *
     * @param nombre  Nombre del mesero.
     * @return        Instancia del BuilderMesero.
     */
    public BuilderMesero setNombre(String nombre) {
        this.nombre = nombre;
        return this;
    }

    /**
     * Establece el apellido del mesero.
     *
     * @param apellido  Apellido del mesero.
     * @return          Instancia del BuilderMesero.
     */
    public BuilderMesero setApellido(String apellido) {
        this.apellido = apellido;
        return this;
    }

    /**
     * Establece el número de celular del mesero.
     *
     * @param celular  Número de celular del mesero.
     * @return         Instancia del BuilderMesero.
     */
    public BuilderMesero setCelular(String celular) {
        this.celular = celular;
        return this;
    }

    /**
     * Establece la dirección del mesero.
     *
     * @param direccion  Dirección del mesero.
     * @return           Instancia del BuilderMesero.
     */
    public BuilderMesero setDireccion(String direccion) {
        this.direccion = direccion;
        return this;
    }

    /**
     * Establece el sueldo del mesero.
     *
     * @param sueldo  Sueldo del mesero.
     * @return        Instancia del BuilderMesero.
     */
    public BuilderMesero setSueldo(Double sueldo) {
        this.sueldo = sueldo;
        return this;
    }

    /**
     * Establece la contraseña del mesero.
     *
     * @param contrasenia  Contraseña del mesero.
     * @return             Instancia del BuilderMesero.
     */
    public BuilderMesero setContrasenia(String contrasenia) {
        this.contrasenia = contrasenia;
        return this;
    }

    /**
     * Construye y retorna una instancia de Mesero.
     *
     * @return  Nueva instancia de Mesero.
     */
    public Mesero build() {
        return new Mesero(nombre, apellido, celular, id, fechaNacimiento, direccion, sueldo, contrasenia);
    }
}
