
package co.edu.uniquindio.proyectofinal.modulo.empleados;

import co.edu.uniquindio.proyectofinal.app.CafeteriaApp;
import co.edu.uniquindio.proyectofinal.modulo.cafeteria.Cafeteria;
import co.edu.uniquindio.proyectofinal.modulo.cafeteria.Caja;
import co.edu.uniquindio.proyectofinal.modulo.producto.Pedido;
import co.edu.uniquindio.proyectofinal.modulo.producto.Producto;

import java.time.LocalDate;
import java.util.List;
public class Cajero extends Empleado {

    // Atributo para manejar la caja asignada al cajero
    private Caja caja;
    private List<Pedido> listaFacturas;

    public Cajero(String nombre, String apellido, String celular, String id, LocalDate fechaNacimiento, String direccion, double sueldo, String contrasenia) {
        super(nombre, apellido, celular, id, fechaNacimiento, direccion, sueldo, contrasenia);
        Cafeteria cafeteria = Cafeteria.getInstance();
        this.caja = cafeteria.getCaja();
    }
    // Método para generar una factura a partir de un pedido
    public void generarFactura(Pedido pedido){
    }
    // Método para actualizar al cajero basado en notificaciones
    // (implementación del método abstracto en ObservadorMenu)
    @Override
    public void actualizar(String mensaje, Producto producto){
        super.actualizar(mensaje, producto);

    }
}