package co.edu.uniquindio.proyectofinal.app;

import co.edu.uniquindio.proyectofinal.controladores.CajeroController;
import co.edu.uniquindio.proyectofinal.modulo.builders.Creacion;
import co.edu.uniquindio.proyectofinal.modulo.cafeteria.Cafeteria;
import co.edu.uniquindio.proyectofinal.modulo.empleados.Empleado;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;
import java.io.IOException;

import static javafx.application.Application.launch;

/**
 * CafeteriaApp

 * Aplicación JavaFX para la gestión de empleados y pedidos de una cafetería.

 * Desarrollado por:
 * - Juan David Ramírez
 * - Juan Esteban Maya
 * - Miguel Ángel Vargas
 * - Helen Xiomara Giraldo

 * Universidad del Quindío
 * Programa de Ingeniería de Sistemas y Computación
 * Programacion II
 * Este proyecto está licenciado bajo la Licencia MIT.
 */
public class CafeteriaApp extends Application {

    private static Scene scene;

    /**
     * Método start que inicializa la aplicación.
     *
     * @param stage el escenario principal de la aplicación
     * @throws IOException si ocurre un error al cargar el archivo FXML
     */
    @Override
    public void start(Stage stage) throws IOException {
        scene = new Scene(loadFXML("/co/edu/uniquindio/proyectofinal/Inicio.fxml"));
        stage.setTitle("Cafetería");
        Image icon = new Image(getClass().getResourceAsStream("/Images/LogoCircular.png"));
        stage.getIcons().add(icon);
        stage.setScene(scene);
        stage.show();
    }

    /**
     * Cambia la raíz de la escena actual a un nuevo diseño FXML.
     *
     * @param fxml la ruta del archivo FXML
     * @throws IOException si ocurre un error al cargar el archivo FXML
     */
    public static void setRoot(String fxml) throws IOException {
        scene.setRoot(loadFXML(fxml));
        Stage stage = (Stage) scene.getWindow();
        stage.setWidth(600);
        stage.setHeight(400);
    }

    /**
     * Cambia la raíz de la escena actual a un nuevo diseño FXML con dimensiones personalizadas.
     *
     * @param fxml la ruta del archivo FXML
     * @param width el ancho deseado del escenario
     * @param height la altura deseada del escenario
     * @throws IOException si ocurre un error al cargar el archivo FXML
     */
    public static void setRoot(String fxml, double width, double height) throws IOException {
        scene.setRoot(loadFXML(fxml));
        Stage stage = (Stage) scene.getWindow();
        stage.setWidth(width);
        stage.setHeight(height);
    }

    /**
     * Carga un archivo FXML y retorna el nodo raíz.
     *
     * @param fxml la ruta del archivo FXML
     * @return el nodo raíz del archivo FXML cargado
     * @throws IOException si ocurre un error al cargar el archivo FXML
     */
    private static Parent loadFXML(String fxml) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(CafeteriaApp.class.getResource(fxml));
        return fxmlLoader.load();
    }

    /**
     * Método main que lanza la aplicación.
     *
     * @param args los argumentos de la línea de comandos
     */
    public static void main(String[] args) {
        Cafeteria cafeteria = Cafeteria.getInstance();

        launch();

    }
}
