package co.edu.uniquindio.proyectofinal.modulo.cafeteria;
import co.edu.uniquindio.proyectofinal.modulo.facade.AlertaFacade;
import co.edu.uniquindio.proyectofinal.modulo.observer.ObservadorMenu;
import co.edu.uniquindio.proyectofinal.modulo.observer.SujetoMenu;
import co.edu.uniquindio.proyectofinal.modulo.producto.AdministradorProducto;
import co.edu.uniquindio.proyectofinal.modulo.producto.Producto;
import javafx.scene.control.Alert;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

public class Menu implements AdministradorProducto, SujetoMenu {
    private List<Producto> listaProductos;
    private List<ObservadorMenu> observadores;
    /*Constructor del menu
    * */
    public Menu() {
        this.listaProductos = new ArrayList<>();
        this.observadores = new ArrayList<>();
    }
    /*implementacion interfaces*/
    /*Metodo para agregar un producto al menu, y notificar a los observadores sobre el cambio
    * */


    public List<Producto> getListaProductos(){
        return listaProductos;
    }

    @Override
    public void agregarProducto(Producto producto) {
        if (!productoExiste(producto)) {
            listaProductos.add(producto);
        } else {
            AlertaFacade.mostrarAlerta("Producto existente",
                    "No es posible crear el producto", "El producto con nombre "
                            + producto.getNombre() + " ya existe.", Alert.AlertType.WARNING);

        }
    }

    /*Metodo para identificar si un producto existe */
    private boolean productoExiste(Producto producto) {
        for (Producto a : listaProductos) {
            if (Objects.equals(a.getNombre(), producto.getNombre())) {
                return true;
            }
        }
        return false;
    }
    /*Metodo para eliminar un producto del menu, y notificar a los observadores sobre el cambio realizado
    * */
    @Override
    public void eliminarProducto(Producto producto) {
        if (productoExiste(producto)) {
            listaProductos.remove(producto);
        } else {
            // Alerta de que el producto no existe (implementación de AlertaFacade)
            AlertaFacade.mostrarAlerta("Producto no encontrado", "No es posible eliminar el producto", "El empleado con ID " + producto.getNombre() + " no existe.", Alert.AlertType.WARNING);
        }
    }
    /*Metodo para agregar un observador
    * */
    @Override
    public void agregarObservador(ObservadorMenu observadorMenu) {
        observadores.add(observadorMenu);
    }
    /*Metodo para eliminar un observador
    * */
    @Override
    public void eliminarObservador(ObservadorMenu observadorMenu) {
        observadores.remove(observadorMenu);
    }
/*Metodo para notificar a los observadores
* */
    @Override
    public void notificarObservadores(String mensaje, Producto producto) {

        for (ObservadorMenu observador : observadores) {
            observador.actualizar(mensaje, producto);
        }
    }
}
