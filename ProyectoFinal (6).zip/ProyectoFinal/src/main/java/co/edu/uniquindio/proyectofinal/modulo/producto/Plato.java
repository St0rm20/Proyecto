package co.edu.uniquindio.proyectofinal.modulo.producto;

import co.edu.uniquindio.proyectofinal.modulo.strategy.DescuentoFijo;
import co.edu.uniquindio.proyectofinal.modulo.strategy.DescuentoStrategy;

public class Plato implements  Producto{
    private String descripcion;
    private double precio;
    private String nombre;
    private DescuentoStrategy descuentoStrategy;


    public Plato(String descripcion, double precio, String nombre,DescuentoStrategy descuentoStrategy) {
        this.descripcion = descripcion;
        this.precio = precio;
        this.nombre = nombre;
        this.descuentoStrategy = descuentoStrategy;

    }
    @Override
    public String getDescripcion(){
        return descripcion;
    }
    @Override
    public double getPrecio(){
        return  precio;
    }
    @Override
    public String getNombre(){
        return nombre;
    }

    /**
     * Método para aplicar el descuento a un plato
     *
     * @return precio del plato con el descuento aplicado
     */
    public double getPrecioConDescuento(){
        return descuentoStrategy.aplicarDescuento(precio);
    }

    /**
     *  Método con el que establecemos la estretagia de descuento
     *
     * @param descuentoStrategy
     */
    public void setDescuentoStrategy(DescuentoStrategy descuentoStrategy) {
        this.descuentoStrategy = descuentoStrategy;
    }
}
