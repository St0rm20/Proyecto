package co.edu.uniquindio.proyectofinal.controladores;

import co.edu.uniquindio.proyectofinal.modulo.builders.BuilderCajero;
import co.edu.uniquindio.proyectofinal.modulo.builders.BuilderMesero;
import co.edu.uniquindio.proyectofinal.modulo.cafeteria.Cafeteria;
import co.edu.uniquindio.proyectofinal.modulo.empleados.Cajero;
import co.edu.uniquindio.proyectofinal.modulo.empleados.Empleado;
import co.edu.uniquindio.proyectofinal.modulo.empleados.Mesero;
import co.edu.uniquindio.proyectofinal.modulo.facade.AlertaFacade;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import javafx.scene.Parent;

import java.io.IOException;
import java.time.LocalDate;
import java.util.Objects;

public class EmpleadoManagerController {
    private Cafeteria cafeteria = Cafeteria.getInstance(); // Instancia de la cafetería
    private ObservableList<Empleado> listaEmpleados; // Lista de empleados observable
    private FilteredList<Empleado> filteredEmpleadoList; // Lista filtrada de empleados
    private Empleado empleadoSeleccionado;

    @FXML
    private TableView<Empleado> tablaEmpleados;

    @FXML
    private TableColumn<Empleado, String> colApellido;

    @FXML
    private TableColumn<Empleado, String> colCelular;

    @FXML
    private TableColumn<Empleado, String> colDireccion;

    @FXML
    private TableColumn<Empleado, String> colFechaNacimiento;

    @FXML
    private TableColumn<Empleado, String> colID;

    @FXML
    private TableColumn<Empleado, String> colNombre;

    @FXML
    private TableColumn<Empleado, Double> colSueldo;

    @FXML
    private TextField getTextApellido;

    @FXML
    private TextField getTextCelular;

    @FXML
    private TextField getTextDireccion;

    @FXML
    private TextField getTextID;

    @FXML
    private TextField getTextNombre;

    @FXML
    private TextField getTextSueldo;

    @FXML
    private DatePicker getDateFechaNacimiento;

    @FXML
    private PasswordField getPasswordContrasenia;

    @FXML
    private TextField getTextConsultaPorNombre;

    @FXML
    void initialize() {
        listaEmpleados = FXCollections.observableArrayList(cafeteria.getListaEmpleados());
        inicializarTabla();
        inicializarValores();
        verSeleccion();
    }

    @FXML
    void onAgregar() throws Exception {
        agregarEmpleado();
    }

    @FXML
    void onConsultar() {
        String consulta = getTextConsultaPorNombre.getText().toLowerCase();
        filteredEmpleadoList.setPredicate(empleado ->
                empleado.getNombre().toLowerCase().contains(consulta) ||
                        empleado.getApellido().toLowerCase().contains(consulta)
        );
    }

    @FXML
    void onActualizar() {
        actualizarEmpleado();
    }

    @FXML
    void onEliminar() {
        eliminarEmpleado();
    }

    @FXML
    void onLimpiar() {
        limpiarDatos();
    }

    private void inicializarTabla() {
        colNombre.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getNombre()));
        colApellido.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getApellido()));
        colCelular.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getCelular()));
        colDireccion.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getDireccion()));
        colFechaNacimiento.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getFechaNacimiento().toString()));
        colID.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getId()));
        colSueldo.setCellValueFactory(cellData -> new SimpleDoubleProperty(cellData.getValue().getSueldo()).asObject());
    }

    private void agregarEmpleado() throws Exception {
        if (validarFormato()) {
            String selectedValue = seleccionarCargo();
            if (selectedValue != null) {
                Empleado empleado;
                if ("Mesero".equals(selectedValue)) {
                    empleado = buildMesero();
                } else if ("Cajero".equals(selectedValue)) {
                    empleado = buildCajero();
                } else {
                    throw new Exception("Invalid employee type");
                }

                if (!empleadoExiste(empleado)) {
                    listaEmpleados.add(empleado);
                    cafeteria.getListaEmpleados().add(empleado);
                    limpiarDatos();
                } else {
                    AlertaFacade.mostrarError("El empleado ya existe");
                }
            }
        } else {
            AlertaFacade.mostrarError("Por favor ingrese los datos correctamente");
        }
    }

    private void eliminarEmpleado() {
        boolean confirmacion = AlertaFacade.mostrarMensajeConfirmacion("Confirmar eliminar");
        if (!confirmacion) {
            return;
        }
        Empleado empleado = tablaEmpleados.getSelectionModel().getSelectedItem();
        if (empleado != null && !empleado.isActivo()) {//verifica empleado inactivo (no esté involucrado en transacciones)
            listaEmpleados.remove(empleado); // Elimina el empleado de la lista observable
            cafeteria.eliminarEmpleado(empleado); // Elimina el empleado de la cafetería
        }
        limpiarDatos();
    }

    private boolean empleadoExiste(Empleado empleado) {
        for (Empleado a : listaEmpleados) {
            if (Objects.equals(a.getId(), empleado.getId())) {
                return true;
            }
        }
        return false;
    }

    private void actualizarEmpleado() {
        verSeleccion();
        if (empleadoSeleccionado != null) {
            if (empleadoSeleccionado instanceof Mesero) {
                Empleado empleadoActualizado = buildMesero();
                actualizarLista(empleadoSeleccionado, empleadoActualizado);
            } else {
                Empleado empleadoActualizado = buildCajero();
                actualizarLista(empleadoSeleccionado, empleadoActualizado);
            }
        }
    }

    private void actualizarLista(Empleado empleadoActual, Empleado empleadoActualizado) {
        int i = listaEmpleados.indexOf(empleadoActual);
        listaEmpleados.set(i, empleadoActualizado);
    }

    private void limpiarDatos() {
        getDateFechaNacimiento.setValue(null);
        getTextCelular.setText("");
        getPasswordContrasenia.setText("");
        getTextApellido.setText("");
        getTextNombre.setText("");
        getTextID.setText("");
        getTextSueldo.setText("");
        getTextDireccion.setText("");
        getTextConsultaPorNombre.setText("");
        onConsultar();
    }
    private void inicializarValores(){
        filteredEmpleadoList = new FilteredList<>(listaEmpleados, p -> true);
        tablaEmpleados.setItems(filteredEmpleadoList);
    }
    private void verSeleccion() {
        tablaEmpleados.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
            empleadoSeleccionado = newSelection;
            mostrarInformacionEmpleado(empleadoSeleccionado);
        });
    }

    private void mostrarInformacionEmpleado(Empleado empleadoSeleccionado) {
        if (empleadoSeleccionado != null) {
            getDateFechaNacimiento.setValue(empleadoSeleccionado.getFechaNacimiento());
            getTextCelular.setText(empleadoSeleccionado.getCelular());
            getPasswordContrasenia.setText(empleadoSeleccionado.getContrasenia());
            getTextApellido.setText(empleadoSeleccionado.getApellido());
            getTextNombre.setText(empleadoSeleccionado.getNombre());
            getTextID.setText(empleadoSeleccionado.getId());
            getTextSueldo.setText(String.valueOf(empleadoSeleccionado.getSueldo()));
            getTextDireccion.setText(empleadoSeleccionado.getDireccion());
        }
    }

    private String seleccionarCargo() throws Exception {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/co/edu/uniquindio/proyectofinal/ElegirCargoEmpleado.fxml"));
        Parent root = fxmlLoader.load();

        // Crear una nueva escena y mostrarla en una nueva ventana (Stage)
        Scene scene = new Scene(root);
        Stage stage = new Stage();
        stage.setScene(scene);
        stage.showAndWait();
        ElegirCargoEmpleadoController elegirCargoEmpleadoController = fxmlLoader.getController();
        return elegirCargoEmpleadoController.OnSeleccionarButton();
    }

    private Cajero buildCajero() {
        return new BuilderCajero(getTextID.getText(), getDateFechaNacimiento.getValue())
                .setNombre(getTextNombre.getText())
                .setApellido(getTextApellido.getText())
                .setCelular(getTextCelular.getText())
                .setDireccion(getTextDireccion.getText())
                .setSueldo(Double.parseDouble(getTextSueldo.getText()))
                .setContrasenia(getPasswordContrasenia.getText())
                .build();
    }

    private Mesero buildMesero() {
        return new BuilderMesero(getTextID.getText(), getDateFechaNacimiento.getValue())
                .setNombre(getTextNombre.getText())
                .setApellido(getTextApellido.getText())
                .setCelular(getTextCelular.getText())
                .setDireccion(getTextDireccion.getText())
                .setSueldo(Double.parseDouble(getTextSueldo.getText()))
                .setContrasenia(getPasswordContrasenia.getText())
                .build();
    }

    private boolean esNumero(String str) {
        if (str == null) {
            return false;
        }
        try {
            Double.parseDouble(str);
        } catch (NumberFormatException e) {
            return false;
        }
        return true;
    }

    private boolean validarFormato() {
        return !getTextNombre.getText().isEmpty()
                && !getTextApellido.getText().isEmpty()
                && !getTextCelular.getText().isEmpty()
                && !getTextID.getText().isEmpty()
                && !getTextSueldo.getText().isEmpty()
                && esNumero(getTextSueldo.getText())  // Validar que sea un número
                && !getPasswordContrasenia.getText().isEmpty()
                && getDateFechaNacimiento.getValue() != null
                && !getTextDireccion.getText().isEmpty();
    }
}
