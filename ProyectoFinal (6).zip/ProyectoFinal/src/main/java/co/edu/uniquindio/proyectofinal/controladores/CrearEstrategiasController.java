package co.edu.uniquindio.proyectofinal.controladores;


import co.edu.uniquindio.proyectofinal.modulo.builders.BuilderDescuentoFijo;
import co.edu.uniquindio.proyectofinal.modulo.builders.BuilderDescuentoPorcentual;
import co.edu.uniquindio.proyectofinal.modulo.cafeteria.Cafeteria;
import co.edu.uniquindio.proyectofinal.modulo.facade.AlertaFacade;
import co.edu.uniquindio.proyectofinal.modulo.strategy.DescuentoFijo;
import co.edu.uniquindio.proyectofinal.modulo.strategy.DescuentoPorcentaje;
import co.edu.uniquindio.proyectofinal.modulo.strategy.DescuentoStrategy;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.image.ImageView;
import java.net.URL;
import java.util.Objects;
import java.util.ResourceBundle;

public class CrearEstrategiasController {

    private Cafeteria cafeteria = Cafeteria.getInstance();
    private ObservableList<DescuentoStrategy> listaEstrategias; // Lista de estrategia observable
    private FilteredList<DescuentoStrategy> filteredEstrategiaList; // Lista filtrada de Estrategia
    private DescuentoStrategy estrategiaSeleccionada;

        @FXML
        private ResourceBundle resources;

        @FXML
        private URL location;

        @FXML
        private TableColumn<DescuentoStrategy, Double> colCantidadPorcentaje;

        @FXML
        private TableColumn<DescuentoStrategy, String> colNombre;

        @FXML
        private TableColumn<DescuentoStrategy, String> colPromocion;


        @FXML
        private ComboBox<String> getBoxPromocion;

        @FXML
        private TextField getTextCantidad;


        @FXML
        private TextField getTextConsultaPorNombre;

        @FXML
        private TextField getTextPromocion;

        @FXML
        private Label nombreAdministradorLabel;

        @FXML
        private Button onActualizar;

        @FXML
        private Button onAgregar;

        @FXML
        private Button onConsultar;

        @FXML
        private Button onEliminar;

        @FXML
        private Button onLimpiar;

        @FXML
        private TableView<DescuentoStrategy> tablaPromociones;

        @FXML
        private Label textCantidad;

        @FXML
        private Label textCelular;

        @FXML
        private Label textConsultaPorNombre;

        @FXML
        private Label textNombre;

        @FXML
        void onActualizar() {

        }

        @FXML
        void onAgregar() {

        }

        @FXML
        void onConsultar() {

        }

        @FXML
        void onEliminar() {

        }

        @FXML
        void onLimpiar() {

        }

        @FXML
        void initialize() {
            listaEstrategias = FXCollections.observableArrayList(cafeteria.getListaEstrategias());
            inicializarTabla();
            inicializarValores();
            verSeleccion();
        }


      private void inicializarValores(){
            listaEstrategias.addAll(cafeteria.getListaEstrategias());
          filteredEstrategiaList = new FilteredList<>(listaEstrategias, p -> true);
    }

    private void inicializarTabla() {
        colPromocion.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getTipo()));
        colCantidadPorcentaje.setCellValueFactory(cellData -> new SimpleDoubleProperty(cellData.getValue().getValor()).asObject());
        colNombre.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getNombre()));
        tablaPromociones.setItems(listaEstrategias);
    }

    private void agregarEstrategia() throws Exception {
        if (validarFormato()) {
                DescuentoStrategy estrategia;
                if ("Fijo".equals(getBoxPromocion.getValue())) {
                    estrategia = buildDescuentoFijo();
                } else if ("Porcentaje".equals(getBoxPromocion.getValue())) {
                    estrategia = buildDescuentoPorcentaje();
                } else {
                    throw new Exception("Invalid employee type");
                }

                if (!estrategiaExiste(estrategia)) {
                    listaEstrategias.add(estrategia);
                    cafeteria.getListaEstrategias().add(estrategia);
                    tablaPromociones.setItems(listaEstrategias);
                    limpiarDatos();
                } else {
                    AlertaFacade.mostrarError("El estrategias ya existe");
                }

        } else {
            AlertaFacade.mostrarError("Por favor ingrese los datos correctamente");
        }
    }

    private void eliminarEstrategias() {
        DescuentoStrategy estrategia = tablaPromociones.getSelectionModel().getSelectedItem();
        if (estrategia != null) {
            listaEstrategias.remove(estrategia); // Elimina la estrategia de la lista observable
            cafeteria.eliminarEstrategia(estrategia); // Elimina la estrategia de la cafetería
        }
        limpiarDatos();
    }

private boolean estrategiaExiste(DescuentoStrategy estrategia) {
    for (DescuentoStrategy a : listaEstrategias) {
        if (Objects.equals(a.getNombre(), estrategia.getNombre())) {
            return true;
        }
    }
    return false;
}

    private void actualizarEstrategia() {
        verSeleccion();
        if (estrategiaSeleccionada != null) {
            if (estrategiaSeleccionada instanceof DescuentoFijo) {
                DescuentoStrategy estrategiaActualizado = buildDescuentoFijo();
                actualizarLista(estrategiaSeleccionada, estrategiaActualizado);
            } else {
                DescuentoStrategy estrategiaActualizado = buildDescuentoPorcentaje();
                actualizarLista(estrategiaSeleccionada, estrategiaActualizado);
            }
        }
    }
    private void actualizarLista(DescuentoStrategy estrategiaActual, DescuentoStrategy estrategiaActualizado){
        int i = listaEstrategias.indexOf(estrategiaActual);
        listaEstrategias.set(i, estrategiaActualizado);
    }
    private void limpiarDatos(){
        getTextCantidad.setText("");
        getTextPromocion.setText("");


    }
    private void verSeleccion() {
        tablaPromociones.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
            estrategiaSeleccionada = newSelection;
            mostrarInformacionEstrategia(estrategiaSeleccionada);
        });
    }

    private void mostrarInformacionEstrategia(DescuentoStrategy estrategiaSeleccionado){
        if(estrategiaSeleccionado!= null){
           getTextCantidad.setText(String.valueOf(estrategiaSeleccionado.getValor()));
           getTextPromocion.setText(estrategiaSeleccionado.getNombre());
        }
    }

    private DescuentoFijo buildDescuentoFijo() {
        return new BuilderDescuentoFijo().setNombre(getTextPromocion.getText())
                .setDescuentoFijo(Double.parseDouble(getTextCantidad.getText())).build();
    }

    private DescuentoPorcentaje buildDescuentoPorcentaje() {
        return new BuilderDescuentoPorcentual().setNombre(getTextPromocion.getText())
                .setPorcentaje(Double.parseDouble(getTextCantidad.getText())).build();

    }

    private boolean esNumero(String str) {
        if (str == null) {
            return false;
        }
        try {
            Double.parseDouble(str);
        } catch (NumberFormatException e) {
            return false;
        }
        return true;
    }


    private boolean validarFormato() {
        return !getTextPromocion.getText().isEmpty()
                && !getTextCantidad.getText().isEmpty()
                && esNumero(getTextCantidad.getText());  // Validar que sea un número
    }
}
