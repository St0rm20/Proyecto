package co.edu.uniquindio.proyectofinal.modulo.proxy;

import co.edu.uniquindio.proyectofinal.modulo.empleados.Cajero;
import co.edu.uniquindio.proyectofinal.modulo.empleados.Empleado;

public class AdministracionCajaProxy implements AdministracionCaja {
    private AdministracionCajaReal administracionCajaReal;
    private Empleado empleado;

    /**
     * Constructor que inicializa el empleado y crea una instancia de la clase real.
     *
     * @param empleado
     */
    public AdministracionCajaProxy (Empleado empleado){
        this.empleado = empleado;
        this.administracionCajaReal = new AdministracionCajaReal();

    }
    /**
     * Verifica si el empleado es un cajero antes de permitirle abrir la caja
     */
    @Override
    public  void abrirCaja() {
        if (esCajero()) {
            administracionCajaReal.abrirCaja();
            ;
        } else {
            System.out.println("Acceso denegado. No tiene permisos para administrar la caja.");
        }
    }

    /** Método privado que verifica si el empleado es una instancia de la clase Cajero
     *
     * @return true o false
     */
    private boolean esCajero(){
        return  empleado instanceof Cajero;

    }
}
