package co.edu.uniquindio.proyectofinal.modulo.proxy;

public class AdministracionCajaReal implements AdministracionCaja{
    @Override
    public void abrirCaja(){
        System.out.println("Administracion de la caja abierta.");
    }
}
