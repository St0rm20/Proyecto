package co.edu.uniquindio.proyectofinal.controladores;

import co.edu.uniquindio.proyectofinal.modulo.cafeteria.Cafeteria;
import co.edu.uniquindio.proyectofinal.modulo.facade.AlertaFacade;
import co.edu.uniquindio.proyectofinal.modulo.producto.Pedido;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.fxml.FXML;
import javafx.scene.control.*;

import java.util.Objects;

public class CajeroController {
    private Cafeteria cafeteria = Cafeteria.getInstance(); // Instancia de la cafetería
    private ObservableList<Pedido> listaPedidos; // Lista de pedidos observable
    private FilteredList<Pedido> filteredPedidosList; // Lista filtrada de pedidos
    private Pedido pedidoSeleccionado;

    @FXML
    private TableView<Pedido> tablaPedidos;

    @FXML
    private TableColumn<Pedido, String> colCodigo;

    @FXML
    private TableColumn<Pedido, Double> colPrecio;

    @FXML
    private TextField getTextCodigo;

    @FXML
    private TextField getTextPrecio;

    @FXML
    private TextField getTextConsultar;

    @FXML
    private Button onAgregar;

    @FXML
    private Button onActualizar;

    @FXML
    private Button onButtonEliminar;

    @FXML
    private Button onConsultar;

    @FXML
    private Button onLimpiar;

    @FXML
    void onAgregar() {
        agregarPedido();
    }

    @FXML
    void onActualizar() {
        actualizarPedido();
    }

    @FXML
    void onButtonEliminar() {
        eliminarPedido();
    }

    @FXML
    void onConsultar() {
        String consulta = getTextConsultar.getText(); // Usa el campo de texto correcto
        if (consulta == null || consulta.isEmpty()) {
            filteredPedidosList.setPredicate(p -> true); // Muestra todos los pedidos si la consulta está vacía
        } else {
            filteredPedidosList.setPredicate(pedido ->
                    pedido.getNumeroSerie().contains(consulta)); // Filtra por el código del pedido
        }
    }

    @FXML
    void onLimpiar() {
        limpiarDatos();
    }

    @FXML
    void initialize() {
        listaPedidos = FXCollections.observableArrayList();
        inicializarValores();
        inicializarTabla();
        verSeleccion();
    }

    private void inicializarValores() {
        listaPedidos.addAll(cafeteria.getListaPedidos());
        filteredPedidosList = new FilteredList<>(listaPedidos, p -> true);
        tablaPedidos.setItems(filteredPedidosList);
    }

    private void inicializarTabla() {
        colCodigo.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getNumeroSerie()));
        colPrecio.setCellValueFactory(cellData -> new SimpleDoubleProperty(cellData.getValue().getTotalCosto()).asObject());
        tablaPedidos.setItems(filteredPedidosList);
    }

    private void agregarPedido() {
        if (validarFormato()) {
            Pedido pedido = new Pedido(getTextCodigo.getText(), Double.parseDouble(getTextPrecio.getText()));

            if (!pedidoExiste(pedido)) {
                listaPedidos.add(pedido);
                cafeteria.getListaPedidos().add(pedido);
                limpiarDatos();
            } else {
                AlertaFacade.mostrarError("El pedido ya existe");
            }
        } else {
            AlertaFacade.mostrarError("Por favor ingrese los datos correctamente");
        }
    }

    private void eliminarPedido() {
        boolean confirmacion = AlertaFacade.mostrarMensajeConfirmacion("Confirmar eliminar");
        if (!confirmacion) {
            return;
        }
        Pedido pedido = tablaPedidos.getSelectionModel().getSelectedItem();
        if (pedido != null) {
            listaPedidos.remove(pedido);
            cafeteria.getListaPedidos().remove(pedido);
        }
        limpiarDatos();
    }

    private boolean pedidoExiste(Pedido pedido) {
        return listaPedidos.stream()
                .anyMatch(p -> Objects.equals(p.getNumeroSerie(), pedido.getNumeroSerie()));
    }

    private void actualizarPedido() {
        verSeleccion();
        if (pedidoSeleccionado != null) {
            Pedido pedidoActualizado = new Pedido(getTextCodigo.getText(), Double.parseDouble(getTextPrecio.getText()));
            listaPedidos.set(listaPedidos.indexOf(pedidoSeleccionado), pedidoActualizado);
            limpiarDatos();
        }
    }

    private void limpiarDatos() {
        getTextCodigo.clear();
        getTextPrecio.clear();
        getTextConsultar.clear();
    }

    private void verSeleccion() {
        tablaPedidos.getSelectionModel().selectedItemProperty()
                .addListener((observable, oldValue, newValue) -> {
                    if (newValue != null) {
                        pedidoSeleccionado = newValue;
                        getTextCodigo.setText(newValue.getNumeroSerie());
                        getTextPrecio.setText(String.valueOf(newValue.getTotalCosto()));
                    }
                });
    }

    private boolean validarFormato() {
        return getTextCodigo.getText() != null && !getTextCodigo.getText().isEmpty()
                && getTextPrecio.getText() != null && !getTextPrecio.getText().isEmpty()
                && getTextPrecio.getText().matches("\\d+(\\.\\d+)?");
    }
}
