package co.edu.uniquindio.proyectofinal.modulo.empleados;

import co.edu.uniquindio.proyectofinal.modulo.cafeteria.Cafeteria;
import co.edu.uniquindio.proyectofinal.modulo.facade.AlertaFacade;
import co.edu.uniquindio.proyectofinal.modulo.producto.Producto;
import javafx.scene.control.Alert;

import java.time.LocalDate;
import java.util.Objects;

public class Administrador extends Empleado implements AdministradorEmpleados {
    private Cafeteria cafeteria;

    public Administrador(String nombre, String apellido, String celular, String id, LocalDate fechaNacimiento, String direccion, double sueldo, String contrasenia) {
        super(nombre, apellido, celular, id, fechaNacimiento, direccion, sueldo, contrasenia);
        cafeteria = Cafeteria.getInstance();
    }

    public Cafeteria getCafeteria() {
        return cafeteria;
    }

    /**
     * Método para r
     * @param empleado
     */
    @Override
    public void registrarEmpleado(Empleado empleado) {
        cafeteria.agregarEmpleado(empleado);
    }

    @Override
    public void eliminarEmpleado(Empleado empleado) {
        cafeteria.getListaEmpleados().remove(empleado);
    }

    /**Agrega un aumento del sueldo a un empleado con base en un porcentaje
     *
     * @param porcentaje
     * @param empleado
     */
    @Override
    public void agregarBonificacion(Double porcentaje,Empleado empleado) {
        double sueldoActual = empleado.getSueldo();
        double bonificacion = sueldoActual*(porcentaje/100);
        double nuevoSueldo = sueldoActual+bonificacion;
        empleado.setSueldo(nuevoSueldo);
    }


    /** Método para actualizar al administrador basado en notificaciones
     * (implementación del método abstracto en ObservadorMenu)
     */
    @Override
    public void actualizar(String mensaje, Producto producto) {
        super.actualizar(mensaje, producto);
    }
/**Método para obtener un empleado por su id
 * */
    @Override
    public Empleado consultarEmpleado(Empleado empleado){
        return cafeteria.obtenerEmpleado(empleado);
    }

}
