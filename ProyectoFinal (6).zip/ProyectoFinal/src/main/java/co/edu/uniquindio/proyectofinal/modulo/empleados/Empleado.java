package co.edu.uniquindio.proyectofinal.modulo.empleados;

import co.edu.uniquindio.proyectofinal.modulo.facade.AlertaFacade;
import co.edu.uniquindio.proyectofinal.modulo.observer.ObservadorMenu;
import co.edu.uniquindio.proyectofinal.modulo.producto.Producto;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.scene.control.Alert;

import java.time.LocalDate;

public abstract class Empleado implements ObservadorMenu {
    protected String nombre;
    protected String apellido;
    protected String celular;
    protected final String id;
    protected final LocalDate fechaNacimiento;
    protected String direccion;
    protected DoubleProperty sueldo;
    protected boolean activo;
    protected String contrasenia;


    public Empleado(String nombre, String apellido, String celular, String id, LocalDate fechaNacimiento, String direccion, double sueldo, String contrasenia) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.celular = celular;
        this.id = id;
        this.fechaNacimiento = fechaNacimiento;
        this.direccion = direccion;
        this.sueldo = new SimpleDoubleProperty(sueldo);
        this.activo = false;
        this.contrasenia = contrasenia;
    }

    public String getNombre() {
        return nombre;
    }

    public String getDireccion() {
        return direccion;
    }

    public LocalDate getFechaNacimiento() {
        return fechaNacimiento;
    }

    public String getId() {
        return id;
    }

    public String getCelular() {
        return celular;
    }

    public String getApellido() {
        return apellido;
    }

    public boolean isActivo() {
        return activo;
    }

    public Double getSueldo() {
        return sueldo.get();
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getContrasenia() {
        return contrasenia;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public void setCelular(String celular) {
        this.celular = celular;
    }


    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public void setSueldo(double sueldo) {
        this.sueldo.set(sueldo);
    }

    public void setActivo(boolean activo) {
        this.activo = activo;
    }

    public DoubleProperty sueldoProperty(){
        return sueldo;
    }

    // Usa el AlertaFacade para mostrar una alerta informativa con el título "Notificación",
    // el encabezado "Nuevo producto" y el mensaje de alerta construido anteriormente
    @Override
    public void actualizar(String mensaje, Producto producto){
        String alerta = "Empleado " + nombre + ": " + mensaje + " (" + producto.getNombre() + ")";
        AlertaFacade.mostrarAlerta("Notificación", "Nuevo producto", alerta, Alert.AlertType.INFORMATION);

    }

}
