package co.edu.uniquindio.proyectofinal.modulo.builders;

import co.edu.uniquindio.proyectofinal.modulo.cafeteria.Caja;
import co.edu.uniquindio.proyectofinal.modulo.cafeteria.Menu;
import co.edu.uniquindio.proyectofinal.modulo.cafeteria.Cafeteria;
import co.edu.uniquindio.proyectofinal.modulo.empleados.Cajero;
import co.edu.uniquindio.proyectofinal.modulo.empleados.Mesero;
import co.edu.uniquindio.proyectofinal.modulo.empleados.Administrador;
import co.edu.uniquindio.proyectofinal.modulo.producto.Bebida;
import co.edu.uniquindio.proyectofinal.modulo.producto.Plato;
import co.edu.uniquindio.proyectofinal.modulo.producto.Producto;
import co.edu.uniquindio.proyectofinal.modulo.producto.Pedido;
import co.edu.uniquindio.proyectofinal.modulo.strategy.DescuentoFijo;
import co.edu.uniquindio.proyectofinal.modulo.strategy.DescuentoPorcentaje;

import java.time.LocalDate;

/**
 * Creacion
 *
 * Clase encargada de crear y agregar instancias de objetos relacionados con la cafetería,
 * como empleados, productos, menú y pedidos, a la instancia singleton de la clase Cafeteria.
 */
public class Creacion {

    private static Cafeteria cafeteria = Cafeteria.getInstance();

    /**
     * Método principal para crear y agregar todas las instancias de objetos a la cafetería.
     */
    public static void crearInstancias(){
        crearAdministradores();
        crearCajeros();
        crearMenu();
        crearMeseros();
        crearPedido();
        crearProductos();
    }


    public static void crearEstrategias(){
        DescuentoFijo descuentoFijo = new DescuentoFijo("Descuento fijo", 500);;
        DescuentoPorcentaje descuentoPorcentaje = new DescuentoPorcentaje(0.1, "Descuento porcentual");
        cafeteria.agregarEstrategia(descuentoFijo);
        cafeteria.agregarEstrategia(descuentoPorcentaje);
    }
    /**
     * Método para crear y agregar instancias de meseros a la cafetería.
     */
    public static void crearMeseros(){
        Mesero mesero1 = new Mesero("Juan", "Carmona", "333221543", "143e", LocalDate.of(1995, 10, 23), "New York #23", 300000, "password123");
        Mesero mesero2 = new Mesero("Maria", "Martínez", "333224321", "145e", LocalDate.of(1990, 5, 15), "Los Angeles #12", 310000, "password456");
        Mesero mesero3 = new Mesero("Martin", "Pérez", "333227890", "146e", LocalDate.of(1985, 3, 10), "San Francisco #5", 320000, "password789");

        cafeteria.agregarEmpleado(mesero1);
        cafeteria.agregarEmpleado(mesero2);
        cafeteria.agregarEmpleado(mesero3);
    }

    /**
     * Método para crear y agregar instancias de administradores a la cafetería.
     */
    public static void crearAdministradores(){
        Administrador administrador1 = new Administrador("Miguel", "Rodriguez", "3112233445", "A001", LocalDate.of(1980, 1, 15), "Calle 10 #20-30", 5000000, "admin123");
        Administrador administrador2 = new Administrador("Sara", "Lopez", "3123344556", "A002", LocalDate.of(1975, 3, 25), "Carrera 15 #10-20", 5200000, "admin456");
        Administrador administrador3 = new Administrador("Carlos", "Martinez", "3134455667", "A003", LocalDate.of(1982, 5, 30), "Avenida 30 #5-10", 5100000, "admin789");

        cafeteria.agregarAdministrador(administrador1);
        cafeteria.agregarAdministrador(administrador2);
        cafeteria.agregarAdministrador(administrador3);
    }

    /**
     * Método para crear y agregar instancias de cajeros a la cafetería.
     */
    public static void crearCajeros(){
        Cajero cajero1 = new Cajero("Carlos", "Gomez", "3112233445", "C001", LocalDate.of(1990, 1, 15), "Calle 10 #20-30", 3000000, "cajero123");
        Cajero cajero2 = new Cajero("Ana", "Martinez", "3123344556", "C002", LocalDate.of(1985, 3, 25), "Carrera 15 #10-20", 3200000, "cajero456");
        Cajero cajero3 = new Cajero("Luis", "Perez", "3134455667", "C003", LocalDate.of(1992, 5, 30), "Avenida 30 #5-10", 3100000, "cajero789");

        cafeteria.agregarEmpleado(cajero1);
        cafeteria.agregarEmpleado(cajero2);
        cafeteria.agregarEmpleado(cajero3);
    }

    /**
     * Método para crear y agregar instancias de productos a la cafetería.
     */
    public static void crearProductos(){
        DescuentoFijo descuento = new DescuentoFijo("Sin descuento", 0);
        Bebida bebida1 = new Bebida("Café", 1500, "Café negro");
        Bebida bebida2 = new Bebida("Matcha", 1500, "Matcha en leche");
        Bebida bebida3 = new Bebida("Te", 1500, "Te negro");
        Plato plato1 = new Plato("Crepe", 1500, "Crepe nutella", descuento);
        Plato plato2 = new Plato("Croissant", 2000, "Croissant de queso", descuento);

        cafeteria.agregarProducto(bebida1);
        cafeteria.agregarProducto(bebida2);
        cafeteria.agregarProducto(bebida3);
        cafeteria.agregarProducto(plato1);
        cafeteria.agregarProducto(plato2);
    }

    /**
     * Método para crear y agregar instancias de productos al menú de la cafetería.
     */
    public static void crearMenu(){
        DescuentoFijo descuento = new DescuentoFijo("Sin descuento", 0);
        Producto producto1 = new Bebida("Café", 1500, "Café colombiano");
        Producto producto2 = new Bebida("Jugo Natural", 2000, "Jugo de naranja natural");
        Producto producto3 = new Plato("Sandwich", 3000, "Sandwich de pollo", descuento);

        Menu menu = cafeteria.getMenu();
        menu.agregarProducto(producto1);
        menu.agregarProducto(producto2);
        menu.agregarProducto(producto3);
    }

    /**
     * Método para crear y agregar instancias de pedidos a la cafetería.
     */
    public static void crearPedido(){
        DescuentoFijo descuento = new DescuentoFijo("Sin descuento", 0);
        Producto producto1 = new Bebida("Café", 1500, "Café colombiano");
        Producto producto2 = new Bebida("Jugo Natural", 2000, "Jugo de naranja natural");
        Producto producto3 = new Plato("Sandwich", 3000, "Sandwich de pollo", descuento);

        Pedido pedido = new Pedido("ABC123", 121212);
        pedido.agregarProducto(producto1);
        pedido.agregarProducto(producto2);
        pedido.agregarProducto(producto3);

        cafeteria.getListaPedidos().add(pedido);
    }
}
