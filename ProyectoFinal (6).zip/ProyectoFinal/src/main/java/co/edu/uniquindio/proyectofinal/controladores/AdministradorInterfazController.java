package co.edu.uniquindio.proyectofinal.controladores;

import javafx.fxml.FXML;

import java.net.URL;
import java.util.ResourceBundle;

public class AdministradorInterfazController
{
    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    void initialize() {

    }
}
