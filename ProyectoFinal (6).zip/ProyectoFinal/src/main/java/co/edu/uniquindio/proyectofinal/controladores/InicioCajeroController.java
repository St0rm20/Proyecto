package co.edu.uniquindio.proyectofinal.controladores;

import co.edu.uniquindio.proyectofinal.app.CafeteriaApp;
import co.edu.uniquindio.proyectofinal.modulo.cafeteria.Cafeteria;
import co.edu.uniquindio.proyectofinal.modulo.empleados.Empleado;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.image.ImageView;
import org.w3c.dom.Text;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class InicioCajeroController {
    private String claveAcceso = "1234";
        Cafeteria cafeteria = Cafeteria.getInstance();
        @FXML
        private ResourceBundle resources;

        @FXML
        private URL location;

        @FXML
        private ImageView getAvatar;

        @FXML
        private Label getTextBienvenido;

        @FXML
        private PasswordField getTextContraseniaCaja;

        @FXML
        private Button onAbrirCaja;

        @FXML
        private Button onCerrarSesion;

        @FXML
        private Label textNombreCajero;


        @FXML
        void onAbrirCaja() throws IOException {
            if(claveAcceso.equals(getTextContraseniaCaja.getText())){
            CafeteriaApp.setRoot("/co/edu/uniquindio/proyectofinal/Caja.fxml",600, 400);
            }
        }

        @FXML
        void onCerrarSesion() throws IOException {
            CafeteriaApp.setRoot("/co/edu/uniquindio/proyectofinal/Inicio.fxml");
        }

    @FXML
    void initialize() {
        Empleado empleado = cafeteria.getUsuarioActual();
        if (empleado != null) {
            textNombreCajero.setText(empleado.getNombre());
        } else {
            // handle the case when empleado is null
        }
    }
}
