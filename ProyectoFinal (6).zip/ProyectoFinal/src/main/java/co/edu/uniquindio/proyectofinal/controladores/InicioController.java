package co.edu.uniquindio.proyectofinal.controladores;

import co.edu.uniquindio.proyectofinal.app.CafeteriaApp;
import co.edu.uniquindio.proyectofinal.modulo.builders.Creacion;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class InicioController {
    private static boolean iniciado = false;
    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button onIniciarSesion;

    @FXML
    private Button onRegistrarse;

    @FXML
    private Label textQueDeseaHacer;

    @FXML
    private void onIniciarSesion()throws IOException  {
        CafeteriaApp.setRoot("/co/edu/uniquindio/proyectofinal/InicioSesion.fxml");
    }

    @FXML
    void onRegistrarse()throws IOException  {
        CafeteriaApp.setRoot("/co/edu/uniquindio/proyectofinal/RegistroUsuario.fxml");
    }

    @FXML
    void initialize() {
        if (!iniciado){
            Creacion.crearInstancias();
            iniciado = true;
        }

    }

}
