package co.edu.uniquindio.proyectofinal.controladores;

import co.edu.uniquindio.proyectofinal.app.CafeteriaApp;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class RegistroUsuarioController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private AnchorPane LogoEmpresa;

    @FXML
    private ImageView logoEmpresa;

    @FXML
    private Button onAdministrador;

    @FXML
    private Button onEmpledo;

    @FXML
    private Button onUndo;

    @FXML
    private Label textCorreo;

    @FXML
    private Label textInicioDeSesion;

    @FXML
    void onAdministrador() throws IOException {
        CafeteriaApp.setRoot("/co/edu/uniquindio/proyectofinal/RegistroAdministrador.fxml",450,600);
    }

    @FXML
    void onEmpledo() throws IOException {
        CafeteriaApp.setRoot("/co/edu/uniquindio/proyectofinal/RegistroEmpleado.fxml",450,600);
    }

    @FXML
    void onUndo() throws IOException {
        CafeteriaApp.setRoot("/co/edu/uniquindio/proyectofinal/Inicio.fxml");
    }

    @FXML
    void  onRegistrar(){

    }

    @FXML
    void initialize() {
    }

    public void onShowing(Event event) {
    }
}
