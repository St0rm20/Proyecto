package co.edu.uniquindio.proyectofinal.modulo.empleados;

import co.edu.uniquindio.proyectofinal.modulo.facade.AlertaFacade;
import co.edu.uniquindio.proyectofinal.modulo.producto.Pedido;
import co.edu.uniquindio.proyectofinal.modulo.producto.Producto;
import javafx.scene.control.Alert;
import java.time.LocalDate;

public class Mesero extends Empleado {

    public Mesero(String nombre, String apellido, String celular, String id, LocalDate fechaNacimiento, String direccion, double sueldo, String contrasenia) {
        super(nombre, apellido, celular, id, fechaNacimiento, direccion, sueldo, contrasenia);

    }

    @Override
    public void actualizar(String mensaje, Producto producto){
        super.actualizar(mensaje, producto);
    }

    public Pedido crearPedido(String numeroDeSerie, double totalCosto){
        Pedido pedido = new Pedido( numeroDeSerie, totalCosto);
        return  pedido;
    }

    public void agregarProductoAPedido(Producto producto, Pedido pedido){
        pedido.agregarProducto(producto);
    }

    public void eliminarProductoPedido(Producto producto, Pedido pedido){
        pedido.eliminarProducto(producto);
    }

    public Producto consultarProducto(Producto producto, Pedido pedido){
        for (Producto x: pedido.getProductos()){
            if (x.equals(producto)) {
                return x;
            }
        }
        AlertaFacade.mostrarAlerta("Producto no existente",
                "No es posible encontrar el producto", "El producto con nombre "
                        + producto.getNombre() + " no existe en el pedido.", Alert.AlertType.WARNING);

        return null;
    }
}
