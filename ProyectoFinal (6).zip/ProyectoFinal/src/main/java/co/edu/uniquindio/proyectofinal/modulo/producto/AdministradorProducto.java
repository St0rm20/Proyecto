package co.edu.uniquindio.proyectofinal.modulo.producto;

public interface AdministradorProducto {
    void agregarProducto(Producto producto);
    void eliminarProducto(Producto producto);
}
