package co.edu.uniquindio.proyectofinal.modulo.builders;
import co.edu.uniquindio.proyectofinal.modulo.strategy.DescuentoPorcentaje;

public class BuilderDescuentoPorcentual {
    private double porcentaje;
    private String nombre;

    public BuilderDescuentoPorcentual() {
    }

    /**
     * Método para establecer el porcentaje de descuento.
     *
     * @param porcentaje El porcentaje de descuento a establecer.
     * @return El builder actual.
     */
    public BuilderDescuentoPorcentual setPorcentaje(double porcentaje) {
        this.porcentaje = porcentaje;
        return this;
    }

    public BuilderDescuentoPorcentual setNombre(String nombre) {
        this.nombre = nombre;
        return this;
    }
    /**
     * Método para construir una instancia de DescuentoPorcentaje.
     *
     * @return Una nueva instancia de DescuentoPorcentaje.
     */
    public DescuentoPorcentaje build() {
        return new DescuentoPorcentaje(porcentaje, nombre);
    }
}

