package co.edu.uniquindio.proyectofinal.modulo.empleados;

public interface AdministradorEmpleados {
    void registrarEmpleado(Empleado empleado);
    void eliminarEmpleado(Empleado empleado);
    void agregarBonificacion(Double porcentaje,Empleado empleado);
    Empleado consultarEmpleado(Empleado empleado);

}
