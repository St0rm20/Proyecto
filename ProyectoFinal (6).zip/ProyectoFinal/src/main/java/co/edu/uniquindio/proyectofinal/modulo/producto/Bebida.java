package co.edu.uniquindio.proyectofinal.modulo.producto;

public class Bebida implements Producto {
    private String descripcion;
    private double precio;
    private String nombre;

    public Bebida(String descripcion, double precio, String nombre) {
        this.descripcion = descripcion;
        this.precio = precio;
        this.nombre = nombre;
    }
    @Override
    public String getDescripcion(){
        return descripcion;
    }
    @Override
    public double getPrecio(){
        return  precio;
    }
    @Override
    public String getNombre(){
        return nombre;
    }
}
