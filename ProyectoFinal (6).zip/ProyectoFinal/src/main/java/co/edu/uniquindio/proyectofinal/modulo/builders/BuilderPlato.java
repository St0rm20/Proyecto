package co.edu.uniquindio.proyectofinal.modulo.builders;

import co.edu.uniquindio.proyectofinal.modulo.producto.Plato;
import co.edu.uniquindio.proyectofinal.modulo.strategy.DescuentoStrategy;

public class BuilderPlato {

    private String descripcion;
    private double precio;
    private String nombre;
    private DescuentoStrategy descuentoStrategy;

    public BuilderPlato() {
    }

    /**
     * Establece la descripción del plato.
     *
     * @param descripcion  descripcion del plato.
     * @return        Instancia del BuilderPlato.
     */
    public BuilderPlato setDescripcion(String descripcion) {
        this.descripcion = descripcion;
        return this;
    }

    /**
     * Establece el precio del plato.
     *
     * @param precio  precio del plato.
     * @return        Instancia del BuilderPlato.
     */
    public BuilderPlato setPrecio(double precio) {
        this.precio = precio;
        return this;
    }

    /**
     * Establece el nombre del plato.
     *
     * @param nombre  nombre del plato.
     * @return        Instancia del BuilderPlato.
     */
    public BuilderPlato setNombre(String nombre) {
        this.nombre = nombre;
        return this;
    }

    /**
     * Establece el descuentostrategy del plato.
     *
     * @param descuentoStrategy  descuentostrategy del plato.
     * @return        Instancia del BuilderPlato.
     */
    public BuilderPlato setDescuentoStrategy(DescuentoStrategy descuentoStrategy) {
        this.descuentoStrategy = descuentoStrategy;
        return this;
    }
    /**
     * Construye y retorna una instancia de Plato.
     *
     * @return  Nueva instancia de Plato.
     */
    public Plato build() {
        return new Plato(descripcion,precio,nombre,descuentoStrategy);
    }
}


