package co.edu.uniquindio.proyectofinal.modulo.observer;

import co.edu.uniquindio.proyectofinal.modulo.producto.Producto;
/*Patron Observer
 *El patron Observer permite notificar a clases suscriptoras el cambio en el estado interno de un objeto observable,
 * en el contexto de cafeteria se usa para notificar a cualquier empleado un cambio en el menu de la cafeteria, puesto que es necesario
 * para ellos conocer que productos disponen en el momento.
 * Para la implementacion se crean dos interfaces Observer y sujeto y se implementan en cada uno de los casos concretos
 * */
public interface ObservadorMenu {
    void actualizar(String mensaje, Producto producto);
}
