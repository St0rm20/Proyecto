package co.edu.uniquindio.proyectofinal.modulo.strategy;

public interface DescuentoStrategy {
    double aplicarDescuento(double precio);
    String getNombre();
    double getValor();
    String getTipo();
}
