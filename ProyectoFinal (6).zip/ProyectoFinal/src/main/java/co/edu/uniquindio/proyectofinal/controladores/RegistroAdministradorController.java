package co.edu.uniquindio.proyectofinal.controladores;
import co.edu.uniquindio.proyectofinal.app.CafeteriaApp;
import co.edu.uniquindio.proyectofinal.modulo.builders.BuilderAdministrador;
import co.edu.uniquindio.proyectofinal.modulo.cafeteria.Cafeteria;
import co.edu.uniquindio.proyectofinal.modulo.empleados.Administrador;
import co.edu.uniquindio.proyectofinal.modulo.facade.AlertaFacade;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
public class RegistroAdministradorController {

    private String claveAcceso = "1234";
    Cafeteria cafeteria = Cafeteria.getInstance();

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private AnchorPane LogoEmpresa;

    @FXML
    private DatePicker getDate;

    @FXML
    private PasswordField getPassword;

    @FXML
    private PasswordField getPasswordKey;

    @FXML
    private TextField getTextNombre;

    @FXML
    private TextField getTextoApellido;

    @FXML
    private TextField getTextoCelular;

    @FXML
    private TextField getTextoID;

    @FXML
    private TextField getTextoSueldo;

    @FXML
    private Button onRegistrar;

    @FXML
    private Button onUndo;

    @FXML
    private Label textInicioDeSesion;

    @FXML
    void onRegistrar() throws Exception {
        if(validarFormato()){

            if(getPasswordKey.getText().equals("1234")){

                Administrador administrador = buildAdministrador();
                cafeteria.agregarAdministrador(administrador);
                CafeteriaApp.setRoot("/co/edu/uniquindio/proyectofinal/AdministradorInterfaz.fxml",800,800);
            }else {
                AlertaFacade.mostrarAdvertencia("Clave de acceso incorrecta");
            }
        } else{
            AlertaFacade.mostrarAdvertencia("Por favor llene todos los campos correctamente");
        }

    }


    @FXML
    void onUndo() throws IOException {
        CafeteriaApp.setRoot("/co/edu/uniquindio/proyectofinal/RegistroUsuario.fxml");
    }

    @FXML
    void initialize() {
    }


    private Administrador buildAdministrador(){
        return new BuilderAdministrador(getTextoID.getText(), getDate.getValue())
                .setNombre(getTextNombre.getText())
                .setApellido(getTextoApellido.getText())
                .setCelular(getTextoCelular.getText())
                .setDireccion(getTextoID.getText())
                .setSueldo(Double.parseDouble(getTextoSueldo.getText()))
                .setContrasenia(getPassword.getText())
                .build();
    }

    private boolean esNumero(String str) {
        if (str == null) {
            return false;
        }
        try {
            Double.parseDouble(str);
        } catch (NumberFormatException e) {
            return false;
        }
        return true;
    }


   private boolean validarFormato() {
        return !getTextNombre.getText().isEmpty()
                && !getTextoApellido.getText().isEmpty()
                && !getTextoCelular.getText().isEmpty()
                && !getTextoID.getText().isEmpty()
                && esNumero(getTextoSueldo.getText())
                && !getPassword.getText().isEmpty()
                && getDate.getValue() != null
                && !getPasswordKey.getText().isEmpty();


    }
}
