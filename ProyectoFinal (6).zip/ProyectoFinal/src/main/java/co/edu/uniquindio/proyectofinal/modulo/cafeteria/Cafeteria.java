package co.edu.uniquindio.proyectofinal.modulo.cafeteria;

import co.edu.uniquindio.proyectofinal.modulo.builders.Creacion;
import co.edu.uniquindio.proyectofinal.modulo.empleados.Administrador;
import co.edu.uniquindio.proyectofinal.modulo.empleados.Empleado;
import co.edu.uniquindio.proyectofinal.modulo.facade.AlertaFacade;
import co.edu.uniquindio.proyectofinal.modulo.producto.Pedido;
import co.edu.uniquindio.proyectofinal.modulo.producto.Producto;
import co.edu.uniquindio.proyectofinal.modulo.strategy.DescuentoStrategy;
import javafx.scene.control.Alert;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Objects;

public class Cafeteria {
    /*Aplicación del patron singleton: El patron singleton bajo el contexto de lo que pide la app
     *Permite crear decoradores extras a los productos, con el objetivo de añadir toppings o adicionales,
     * Ejemplo leche adicional a un cafe.
     * */
    private static Cafeteria instance; // Singleton instance

    private String nombre;
    private Menu menu;
    private ArrayList<Empleado> listaEmpleados;
    private ArrayList<Pedido> listaPedidos;
    private ArrayList<Producto> listaProductos;
    private ArrayList<Administrador> listaAdministradores;
    private ArrayList<DescuentoStrategy> listaEstrategias;
    private Caja caja;
    private Empleado usuarioActual;


    private Cafeteria() {
        this.nombre = "Nombre de la cafeteria";
        this.menu = new Menu();
        listaEmpleados = new ArrayList<>();
        listaPedidos = new ArrayList<>();
        listaProductos = new ArrayList<>();
        listaAdministradores = new ArrayList<>();
        listaEstrategias = new ArrayList<>();
        caja = new Caja();
    }
    /*
    *Método para obtener instancia de cafeteria, necesario para el singletone
    */
    public static Cafeteria getInstance() {
        if (instance == null) {
            instance = new Cafeteria();
        }
        return instance;
    }

    public Empleado getUsuarioActual() {
        return usuarioActual;
    }

    public void setUsuarioActual(Empleado usuarioActual) {
        this.usuarioActual = usuarioActual;
    }

    public String getNombre() {
        return nombre;
    }
    /*Getters and Setters*/

    public Menu getMenu() {
        return menu;
    }

    public Caja getCaja() {
        return caja;
    }

    public ArrayList<Producto> getListaProductos() {
        return listaProductos;
    }

    public ArrayList<Empleado> getListaEmpleados() {
        return listaEmpleados;
    }

    public ArrayList<Pedido> getListaPedidos() {
        return listaPedidos;
    }

    public ArrayList<DescuentoStrategy> getListaEstrategias() {
        return listaEstrategias;
    }

    public ArrayList<Administrador> getListaAdministradores() {
        return listaAdministradores;
    }

    public void setListaAdministradores(ArrayList<Administrador> listaAdministradores) {
        this.listaAdministradores = listaAdministradores;
    }
    /*
    *Método para agregar un nuevo administrador a la cafeteria
    */
    public void agregarAdministrador(Administrador administrador) {
        if (!administradorExiste(administrador)) {
            listaAdministradores.add(administrador);
        } else {
            // Alerta de que el administrador ya existe (implementación de AlertaFacade)
            AlertaFacade.mostrarAlerta("Empleado existente", "No es posible crear el Administrador", "El administrador con ID " + administrador.getId() + " ya existe.", Alert.AlertType.WARNING);
        }
    }
    /*
     *Método para agregar un nuevo pedido a la cafeteria
     */
    public void agregarPedido(Pedido pedido) {
        if (!pedidoExiste(pedido)) {
            listaPedidos.add(pedido);
        } else {
            // Alerta de que el pedido ya existe (implementación de AlertaFacade)
            AlertaFacade.mostrarAlerta("Pedido existente", "No es posible crear el Pedido", "El Pedido con Código " + pedido.getNumeroSerie() + " ya existe.", Alert.AlertType.WARNING);
        }
    }
    /*metodo para identificar si un pedido existe*/
    private boolean pedidoExiste(Pedido pedido) {
        for (Pedido a : listaPedidos) {
            if (Objects.equals(a.getNumeroSerie(), pedido.getNumeroSerie())) {
                return true;
            }
        }
        return false;
    }
    /*Metodo para eliminar un empleado de la cafeteria*/
    public void eliminarEmpleado(Empleado empleado) {
        if (empleadoExiste(empleado)) {
            listaEmpleados.remove(empleado);
        } else {
            // Alerta de que el empleado no existe (implementación de AlertaFacade)
            AlertaFacade.mostrarAlerta("Empleado no encontrado", "No es posible eliminar el empleado", "El empleado con ID " + empleado.getId() + " no existe.", Alert.AlertType.WARNING);
        }
    }
    /*Metodo para eliminar un Producto de la cafeteria*/
    public void eliminarProducto(Producto producto) {
        if (productoExiste(producto)) {
            menu.getListaProductos().remove(producto);
        } else {
            // Alerta de que el producto no existe (implementación de AlertaFacade)
            AlertaFacade.mostrarAlerta("Producto no encontrado", "No es posible eliminar el producto", "El empleado con ID " + producto.getNombre() + " no existe.", Alert.AlertType.WARNING);
        }
    }
    /*Metodo para eliminar una Estrategia de la cafeteria*/
    public void eliminarEstrategia(DescuentoStrategy estrategia) {
        if (estrategiaExiste(estrategia)) {
            listaEstrategias.remove(estrategia);
        } else {
            // Alerta de que la estrategia no existe (implementación de AlertaFacade)
            AlertaFacade.mostrarAlerta("estrategia no encontrado", "No es posible eliminar la estrategia", "la estrategia con nombre " + estrategia.getNombre() + " no existe.", Alert.AlertType.WARNING);
        }
    }

    /*metodo para identificar si un administrador existe*/
    private boolean administradorExiste(Administrador administrador) {
        for (Administrador a : listaAdministradores) {
            if (Objects.equals(a.getId(), administrador.getId())) {
                return true;
            }
        }
        return false;
    }
    /*Metodo para identificar si un empleado existe */
    private boolean empleadoExiste(Empleado empleado) {
        for (Empleado a : listaEmpleados) {
            if (Objects.equals(a.getId(), empleado.getId())) {
                return true;
            }
        }
        return false;
    }
    /*Metodo para identificar si un producto existe */
    private boolean productoExiste(Producto producto) {
        for (Producto a : listaProductos) {
            if (Objects.equals(a.getNombre(), producto.getNombre())) {
                return true;
            }
        }
        return false;
    }
    /*Metodo para identificar si una estrategia existe */
    private boolean estrategiaExiste(DescuentoStrategy estrategia) {
        for (DescuentoStrategy a : listaEstrategias) {
            if (Objects.equals(a.getNombre(), estrategia.getNombre())) {
                return true;
            }
        }
        return false;
    }
    /*Metodo para agregar un empleado a la cafeteria */
    public void agregarEmpleado(Empleado empleado) {
        if (!empleadoExiste(empleado)) {
            listaEmpleados.add(empleado);
        } else {
            AlertaFacade.mostrarAlerta("Empleado existente",
                    "No es posible crear el empleado", "El empleado con ID "
                            + empleado.getId() + " ya existe.", Alert.AlertType.WARNING);

        }
    }
    /*Metodo para agregar un producto a la cafeteria */
    public void agregarProducto(Producto producto) {
        if (!productoExiste(producto)) {
            menu.getListaProductos().add(producto);
        } else {
            AlertaFacade.mostrarAlerta("Producto existente",
                    "No es posible crear el producto", "El producto con nombre "
                            + producto.getNombre() + " ya existe.", Alert.AlertType.WARNING);

        }
    }
    /*Metodo para agregar una estrategia a la cafeteria */
    public void agregarEstrategia(DescuentoStrategy estrategia) {
        if (!estrategiaExiste(estrategia)) {
            listaEstrategias.add(estrategia);
        } else {
            AlertaFacade.mostrarAlerta("Estrategia existente",
                    "No es posible crear la estrategia", "La estrategia con nombre "
                            + estrategia.getNombre() + " ya existe.", Alert.AlertType.WARNING);

        }
    }
    /**Método para obtener un empleado por su id
     * */
    public Empleado obtenerEmpleado(Empleado empleado) {
        for (Empleado e : listaEmpleados) {
            if (Objects.equals(e.getId(), empleado.getId())) {
                return e;
            }
        }
        // Alerta de que el empleado no existe (implementación de AlertaFacade)
        AlertaFacade.mostrarAlerta("Empleado no encontrado", "No es posible obtener el empleado", "El empleado con ID " + empleado.getId() + " no existe.", Alert.AlertType.WARNING);
        return null;
    }

    /**Método para obtener un producto por su nombre
     * */
    public Producto obtenerProducto(Producto producto) {
        for (Producto e : menu.getListaProductos()) {
            if (Objects.equals(e.getNombre(), producto.getNombre())) {
                return e;
            }
        }
        // Alerta de que el producto no existe (implementación de AlertaFacade)
        AlertaFacade.mostrarAlerta("producto no encontrado", "No es posible obtener el producto", "El producto con nombre " + producto.getNombre() + " no existe.", Alert.AlertType.WARNING);
        return null;
    }
    /**Método para obtener una estrategia por su nombre
     * */
    public DescuentoStrategy obtenerEstrategias(DescuentoStrategy estrategia) {
        for (DescuentoStrategy e : listaEstrategias) {
            if (Objects.equals(e.getNombre(), estrategia.getNombre())) {
                return e;
            }
        }
        // Alerta de que la estrategia existe (implementación de AlertaFacade)
        AlertaFacade.mostrarAlerta("estrategia no encontrada", "No es posible obtener la estrategia", "la estrategia con nombre " + estrategia.getNombre() + " no existe.", Alert.AlertType.WARNING);
        return null;
    }

}


