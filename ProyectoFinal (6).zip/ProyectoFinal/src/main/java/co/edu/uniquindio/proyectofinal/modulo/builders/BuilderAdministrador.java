package co.edu.uniquindio.proyectofinal.modulo.builders;

import co.edu.uniquindio.proyectofinal.modulo.empleados.Administrador;

import java.time.LocalDate;

/**
 * Builder para crear instancias de Administrador.
 */
public class BuilderAdministrador {
    private String nombre;
    private String apellido;
    private String celular;
    private String id;
    private LocalDate fechaNacimiento;
    private String direccion;
    private Double sueldo;
    private String contrasenia;

    /**
     * Constructor para el BuilderAdministrador.
     *
     * @param id               ID del administrador.
     * @param fechaNacimiento  Fecha de nacimiento del administrador.
     */
    public BuilderAdministrador(String id, LocalDate fechaNacimiento) {
        this.id = id;
        this.fechaNacimiento = fechaNacimiento;
    }

    /**
     * Establece el nombre del administrador.
     *
     * @param nombre  Nombre del administrador.
     * @return        Instancia del BuilderAdministrador.
     */
    public BuilderAdministrador setNombre(String nombre) {
        this.nombre = nombre;
        return this;
    }

    /**
     * Establece el apellido del administrador.
     *
     * @param apellido  Apellido del administrador.
     * @return          Instancia del BuilderAdministrador.
     */
    public BuilderAdministrador setApellido(String apellido) {
        this.apellido = apellido;
        return this;
    }

    /**
     * Establece el número de celular del administrador.
     *
     * @param celular  Número de celular del administrador.
     * @return         Instancia del BuilderAdministrador.
     */
    public BuilderAdministrador setCelular(String celular) {
        this.celular = celular;
        return this;
    }

    /**
     * Establece la dirección del administrador.
     *
     * @param direccion  Dirección del administrador.
     * @return           Instancia del BuilderAdministrador.
     */
    public BuilderAdministrador setDireccion(String direccion) {
        this.direccion = direccion;
        return this;
    }

    /**
     * Establece el sueldo del administrador.
     *
     * @param sueldo  Sueldo del administrador.
     * @return        Instancia del BuilderAdministrador.
     */
    public BuilderAdministrador setSueldo(Double sueldo) {
        this.sueldo = sueldo;
        return this;
    }

    /**
     * Establece la contraseña del administrador.
     *
     * @param contrasenia  Contraseña del administrador.
     * @return             Instancia del BuilderAdministrador.
     */
    public BuilderAdministrador setContrasenia(String contrasenia) {
        this.contrasenia = contrasenia;
        return this;
    }

    /**
     * Construye y retorna una instancia de Administrador.
     *
     * @return  Nueva instancia de Administrador.
     */
    public Administrador build() {
        return new Administrador(nombre, apellido, celular, id, fechaNacimiento, direccion, sueldo, contrasenia);
    }
}
