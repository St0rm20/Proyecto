package co.edu.uniquindio.proyectofinal.modulo.producto;

import co.edu.uniquindio.proyectofinal.modulo.memento.PedidoMemento;

import java.util.ArrayList;
import java.util.List;


public class Pedido implements AdministradorProducto {
    private List<Producto> listaProductos;
    private String numeroSerie;
    private double totalCosto;

    public Pedido(String numeroSerie,double totalCosto) {
        this.listaProductos = new ArrayList<>();
        this.numeroSerie = numeroSerie;
        this.totalCosto = totalCosto;
    }

    public List<Producto> getProductos() {
        return listaProductos;
    }

    public List<Producto> getListaProductos() {
        return listaProductos;
    }

    public String getNumeroSerie() {
        return numeroSerie;
    }

    public double getTotalCosto() {
        return totalCosto;
    }

    @Override
    public void agregarProducto(Producto producto) {
        listaProductos.add(producto);
    }

    @Override
    public void eliminarProducto(Producto producto) {
        listaProductos.remove(producto);
    }

    /**
     * Suma los precios de todos los productos usando un stream
     *
     * @return costo total del pedido
     */
    public double obtenerTotalCosto(){
        return listaProductos.stream().mapToDouble(Producto::getPrecio).sum();
    }

    /**
     * Crea un memento con el estado actual de la lista de productos y el número de serie
     *
     * @return memento estado actual
    */
    public PedidoMemento guardarEstado() {
        return new PedidoMemento(listaProductos, numeroSerie);
    }

    /**
     * Restaura el estado anterior del pedido desde un memento
     *
     * @param memento PedidoMemento que representa el memento anterior
    */
    public void restaurarEstado(PedidoMemento memento) {
        listaProductos = new ArrayList<>(memento.getListaProductos());
        numeroSerie = memento.getNumeroSerie();
    }


}
