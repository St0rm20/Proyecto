package co.edu.uniquindio.proyectofinal.modulo.observer;
import co.edu.uniquindio.proyectofinal.modulo.producto.Producto;

/**
 *  Interfaz SujetoMenu que define los métodos para gestionar observadores
 *
 */

public interface SujetoMenu {
    void agregarObservador (ObservadorMenu observadorMenu);
    void eliminarObservador (ObservadorMenu observadorMenu);
    void notificarObservadores(String mensaje, Producto producto);

}
